<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('navbar_teacher.php'); ?>
        <div class="container-fluid">
                     <div class="row-fluid">
					   <div>
							<a id="print" class="btn btn-info v"><i class="fas fa-print"></i> Print Student List</a>
							
							<a id="close" onclick="window.close();" class="btn btn-info v"><i class="fas fa-times"></i> Close</a>
</div>					
						
						<script>
						function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$(document.getElementById('print')).on('click',function(){
printData();

})
</script>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 v">Students List</h1>
    
</div>
<div class="card-body b">
                        <!-- block -->
                        <div class="table-responsive">
							<table cellpadding="1" cellspacing="0" border="1" class="table" id="printTable">
							
										<thead>
										        <tr>
												<th>Firstname</th>
												<th>Lastname</th>
												</tr>
												
										</thead>
										<tbody>
											
												<?php
														$my_student = mysqli_query($conn,"SELECT * FROM teacher_class_student
														LEFT JOIN student ON student.student_id = teacher_class_student.student_id 
														INNER JOIN class ON class.class_id = student.class_id where teacher_class_id = '$get_id' order by lastname ")or die(mysqli_error());
														while($row = mysqli_fetch_array($my_student)){
														$id = $row['teacher_class_student_id'];
														?>                          
										<tr id="del<?php echo $id; ?>">
									
										 <td><?php echo $row['firstname']; ?></td>
                                         <td><?php  echo $row['lastname']; ?></td>
                             
                             

                               
                                </tr>
                         
						 <?php } ?>
						   
                              
										</tbody>
									</table>
									</div>
									</div>
									</div>	</div>
		<?php include('admin/footer.php'); ?>
   		<?php include('script.php'); ?>
