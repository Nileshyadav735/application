<?php
include('admin/meet/config.php');
include('admin/meet/api.php');
$arr['topic']='LMS CAMPUS';
$arr['start_date']=date('2021-05-16 00:02:30');
$arr['duration']=60;
$arr['password']='campus';
$arr['type']='2';
$result=createMeeting($arr);
if(isset($result->id)){
	 "Join URL: <a href='".$result->join_url."'>".$result->join_url."</a><br/>";
	 "Password: ".$result->password."<br/>";
	 "Start Time: ".$result->start_time."<br/>";
	 "Duration: ".$result->duration."<br/>";
}else{
	 '<pre>';
	print_r($result);
}
?>