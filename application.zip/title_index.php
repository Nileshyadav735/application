						<div class="span4">
						<img class="index_logo"  src="admin/img/Logo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="">Campus Online ACPCE</p>
							<h3>

							<p>Learning</p>
						
							</h3>		
						</div>
			
					
								<div class="motto">
												<p>TEIT Project</p>
												<p>Where knowledge is Second Nature</p>
												<p>Information Technology</p>
								</div>		
					