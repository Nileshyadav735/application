<?php $get_id = $_GET['id']; ?>
<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Material</h1>
   		 		</div>
	<div class="row">
	<div class="col-xl col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Your Shared Files</h6>
										<?php $class_query = mysqli_query($conn,"select * from teacher_class
										LEFT JOIN class ON class.class_id = teacher_class.class_id
										LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
										where teacher_class_id = '$get_id'")or die(mysqli_error());
										$class_row = mysqli_fetch_array($class_query);
										$class_id = $class_row['class_id'];
										$school_year = $class_row['school_year'];
										?>
					 
					 
					        
									<div class="float-right">
							Check All <input type="checkbox"  name="selectAll" id="checkAll" />
								<script>
								$("#checkAll").click(function () {
									$('input:checkbox').not(this).prop('checked', this.checked);
								});
								</script>					
						</div>
									</div>
									
								
									<?php
										$query = mysqli_query($conn,"select * FROM files where class_id = '$get_id'  order by fdatein DESC ")or die(mysqli_error());
										$count = mysqli_fetch_array($query);
										if ($count == '0'){ ?>
											<div class="alert alert-info"><i class="fas fa-info"></i> Currently you did not upload any downloadable materials</div>
						
									<?php	}else{
									?>  
  								<form action="copy_file.php" method="post">
								
									<a data-toggle="modal" href="#user_delete" id="delete"  class="btn btn-info v" name=""><i class="fas fa-clone"></i> Share Check item</a>
									<button class="open-button btn btn-info v" onclick="openFormd(); myFunctiond()"><i class="fas fa-plus"></i>Add Downloadable</button>
									
									<input type="text" id="myInput" class="fas fa-search" onkeyup="myFunction()" placeholder=" &#xF002; Search for File.." title="Type in a name">
  <div class="table-responsove b v">
									  <table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
									<?php include('move_to_school_year.php'); ?>
										<thead>
										        <tr>
												<th>Date Upload</th>
												<th>File Name</th>
												<th>Description</th>
												<th>Uploaded by</th>
												<th></th>
												<th></th>
												</tr>
												
										</thead>
										<tbody>
											
                              		<?php
										$query = mysqli_query($conn,"select * FROM files where class_id = '$get_id'  order by fdatein DESC ")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
										$id  = $row['file_id'];
									?>                              
										<tr id="del<?php echo $id; ?>">
									
										 <td><?php echo $row['fdatein']; ?></td>
                                         <td><?php  echo $row['fname']; ?></td>
                                         <td><?php echo $row['fdesc']; ?></td>                                      
                                         <td><?php echo $row['uploaded_by']; ?></td>                                      
                                         <td width="60">
										 <a  data-placement="bottom" title="Download" id="<?php echo $id; ?>download" href="<?php echo $row['floc']; ?>"><i class="fas fa-download icon-large"> </i></a>
										 <a  data-placement="bottom" title="Remove" name="remove" id="" href="#delete<?php echo $id; ?>" data-toggle="modal"><i class="fas fa-times icon-large"></i></a>
										 <?php include('delete_download_modal.php'); ?>
										 </td>                                      
										<td width="30">
											<input id="" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
										</td>
                             
														<script type="text/javascript">
														$(document).ready(function(){
															$('#<?php echo $id; ?>download').tooltip('show');
															$('#<?php echo $id; ?>download').tooltip('hide');
														});
														</script>
														<script type="text/javascript">
														$(document).ready(function(){
															$('#<?php echo $id; ?>remove').tooltip('show');
															$('#<?php echo $id; ?>remove').tooltip('hide');
														});
														</script>
                               
                                </tr>
                         
						 <?php } ?>
						   
                              
										</tbody>
									</table>	
									<script>
function myFunctiond() {
  var elmnt = document.getElementById("myFormd");
  elmnt.scrollIntoView();
}
</script>
<script src="admin/swal.js"></script>

</script>	
<script type="text/javascript">
	$(document).ready( function() {
	$('.remove').click( function() {
		
		var id = $(this).attr("id");
			$.ajax({
			type: "POST",
			url: "delete_file.php",
			data: ({id: id}),
			cache: false,
			success: function(html){
			$("#del"+id).fadeOut('fast', function(){ $(this).remove();}); 
			$('#delete'+id).modal('hide');
			swal("Your Post is Successfully Deleted");
			setTimeout(() => {window.location.reload();
				
			}, 700); 
			}
			}); 
			
			return false;
		});				
	});

</script>

									</form>
									</div>
						<?php } ?>
						<?php include('downloadable_sidebar.php') ?>
      
						</div>
                            </div>
                        </div>
                        <!-- /block -->
                </div>
		<?php include('admin/footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
				