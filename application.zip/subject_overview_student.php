<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('my_classmates_link.php'); ?>
<?php include('navbar_student.php'); ?>
<div class="container-fluid">
             
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Subject Overview</h1>
   		 		</div>
	
<div class="row">
                <div class="col-xl col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Overview</h6>
						
</div>
<div class="card-body b">	
	<center>
  											<?php $query = mysqli_query($conn,"select * from teacher_class
										LEFT JOIN class ON class.class_id = teacher_class.class_id
										LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
										LEFT JOIN teacher ON teacher.teacher_id = teacher_class.teacher_id
										
										where teacher_class_id = '$get_id'")or die(mysqli_error());
										$row = mysqli_fetch_array($query);
										$id = $row['teacher_class_id'];
				
										?>
										<img id="avatar" style="border-radius: 50%;" class="img-polaroid" src="admin/<?php echo $row['location']; ?>" height="200" width="200">
										<br>
										Instructor: <strong><?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?></strong>
										<p><a href=""><i class="fas fa-search"></i> view info</a></p>
															<hr>
										<?php $query = mysqli_query($conn,"select * from teacher_class
											LEFT JOIN class_subject_overview ON class_subject_overview.teacher_class_id = teacher_class.teacher_class_id
											where class_subject_overview.teacher_class_id = '$get_id'")or die(mysqli_error());
											$row_subject = mysqli_fetch_array($query); ?>
										<?php echo $row_subject['content']; ?>
</center>
									</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
					</div>

<?php include('admin/footer.php'); ?>

<?php include('script.php'); ?>

