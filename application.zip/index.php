
<?php include('header.php'); ?>
<?php include('header_dashboard.php'); ?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Campus</a>
    <button class="navbar-toggler" type="button"  data-mdb-toggle="collapse"  data-mdb-target="#navbarNav" aria-controls="navbarNav"    aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
	<?php include('link.php'); ?>
    </div>
  </div>
</nav>
<div class="jumbotron card card-image" style="background-image: url(https://mdbcdn.b-cdn.net/img/Photos/Others/gradient1.jpg);">
  <div class=" text-center text-white py-5 px-4">
    <div>
    <h2 class="card-title h1-responsive pt-3 mb-5 font-bold"><strong><?php include('title_index.php'); ?></strong></h2>
    <p class="mx-5 mb-5"> </p>
      <a href="" class="btn btn-info v " data-toggle="modal" data-target="#modalLRForm"><i class="fas fa-user left fa-fw"></i>I'm a Student</a>
      <?php include('login_form.php'); ?>
      <a href="" class="btn btn-info v" data-toggle="modal" data-target="#modalLRFormT"><i class="fas fa-user left fa-fw"></i>I'm a Teacher</a>
      <?php include('signup_teacher_form.php'); ?>   
	  <?php include('script.php'); ?>

   </div>
  </div>
</div>
<?php include('admin/footer.php'); ?>
<script src="admin/swal.js"></script>
  <script>
						jQuery(document).ready(function(){
						jQuery("#login_form1").submit(function(e){
								e.preventDefault();
								var formData = jQuery(this).serialize();
								$.ajax({
									type: "POST",
									url: "login.php",
									data: formData,
									success: function(html){
									if(html=='true')
									{
										swal("Please Login As Teacher");
									}else if (html == 'true_student'){
										swal("Welcome to Class");
										
									var delay = 300;
										setTimeout(function(){ window.location = 'student_notification.php'  }, delay);  
									}else
									{
									swal("Please Check your username and Password", { header: 'Login Failed' });
									}
									}
								});
								return false;
							});
						});
						</script>


<script>
						jQuery(document).ready(function(){
						jQuery("#login_formT").submit(function(e){
								e.preventDefault();
								var formData = jQuery(this).serialize();
								$.ajax({
									type: "POST",
									url: "login.php",
									data: formData,
									success: function(html){
									if(html=='true')
									{
									 swal("Welcome to Class");
									 var delay = 300;
										setTimeout(function(){ window.location = 'dasboard_teacher.php'  }, delay);   
									
									}
									else if (html == 'true_student'){
										swal("Please Login As Student");
									
									}
											else
									{
									swal("INVALID Data OR Inactive USER");
									}
									}
								});
								return false;
							});
						});
						</script>
 <script>
			jQuery(document).ready(function(){
			jQuery("#signin_student").submit(function(e){
					e.preventDefault();
						
						var password1 = jQuery('#password').val();
						var cpassword = jQuery('#cpassword').val();
					var email=jQuery('#email').val();
					
					if (password1 == cpassword){
					var formData = jQuery(this).serialize();
					$.ajax({
						
						type: "POST",
						url: "student_signup.php",
						data: formData,
						success: function(html){
						if(html=='true')
						{
						swal("Welcome to Class");
						var delay = 200;
							setTimeout(function(){ window.location = 'dashboard_student.php'  }, delay);  
						}else if(html=='false'){
							swal("student does not found in the database Please Sure to Check Your ID Number or Firstname, Lastname and the Section You Belong. ");
						}
						}
						
						
					});
			
					}else
						{
						swal("student does not found in the database", { header: 'Sign Up Failed' });
						}
				});
			});
			</script>



<script>
			jQuery(document).ready(function(){
			jQuery("#signin_teacher").submit(function(e){
					e.preventDefault();
						var password = jQuery('#password').val();
						var cpassword = jQuery('#cpassword').val();
					if (password == cpassword){
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "teacher_signup.php",
						data: formData,
						success: function(html){
						if(html=='true')
						{
						swal("Sucessfully Registered");
					console.log("success");							 
						}}
					});
					}				
					else
						{
						swal("Something Went Wrong");
						}
				});
			});
			</script>
          	
              
              
              <script>  $(document).ready(function(){
															$('#signin').tooltip('show');
															$('#signin').tooltip('hide');
														});
														</script>	
                                                         <script type="text/javascript">
														$(document).ready(function(){
															$('#signin_student').tooltip('show'); $('#signin_student').tooltip('hide');
														});
														</script>	
														<script type="text/javascript">
														$(document).ready(function(){
															$('#signin_teacher').tooltip('show'); $('#signin_teacher').tooltip('hide');
														});
														</script>	
