<?php /*  define('acccess',true)

if(!defined('access')){
header('location:admin/index.php');
}
*/ 
?>
<ul class="navbar-nav mr-auto">
    	 
 
		<li class="nav-item active"><a class="nav-link" href="index.php"><i class="fas fa-home"></i>&nbsp;Home<span class="sr-only">(current)</span></a></li>
		<li class="nav-item"><a class="nav-link" href="#calendar_of_events" data-toggle="modal"><i class="fas fa-calendar"></i>&nbsp;Calendar of Events</a><?php include('calendar_of_events.php'); ?></li>
		<li class="nav-item"><a class="nav-link" href="#directories" data-toggle="modal"><i class="fas fa-phone"></i>&nbsp;Directories</a>	<?php include('directories.php'); ?> </li>
		<li class="nav-item"><a class="nav-link" href="#campuses" data-toggle="modal"><i class="fas fa-building"></i>&nbsp;Campuses</a>	<?php include('campuses.php'); ?></li>
		<li class="nav-item"><a class="nav-link" href="#history" data-toggle="modal"><i class="fas fa-file"></i>&nbsp;History</a><?php include('history.php'); ?></li>
		<li class="nav-item"><a class="nav-link" href="#developers" data-toggle="modal"><i class="fas fa-user"></i>&nbsp;Developers</a><?php include('developers.php'); ?></li>
<li class="nav-item"><a class="nav-link" href="#about" data-toggle="modal"><i class="fas fa-info"></i>&nbsp;About</a><?php include('about.php'); ?></li>

<li class="nav-item float-right"><a class="nav-link" href="/admin" ><i class="fas fa-user"></i>&nbsp;Admin Login</a></li>

       </ul>
	  