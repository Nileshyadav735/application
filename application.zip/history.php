<div class="modal fade" role="dialog" aria-labelledby="myModalLabel" id="history">
  <div class="modal-dialog modal-xl ">
    <div class="modal-content cascading-modal">
      <div class="modal-header">
	  <h3 id="myModalLabel">History</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body"> 
   
                                <div class="">
									
                                <?php
											$mission_query = mysqli_query($conn,"select * from content where title  = 'History' ")or die(mysqli_error());
											$mission_row = mysqli_fetch_array($mission_query);
											echo $mission_row['content'];
										?>
								
                                </div>
                            
</div>
      <div class="modal-footer">
	  <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i>close</button>
	</div>
    </div>
  </div>
</div> 
 




