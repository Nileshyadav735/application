 
<?php $get_id = $_GET['id']; ?>
<?php $subject_id = $_GET['subject_id']; ?>
<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
 
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Subject Overview</h1>
   		 		</div>
					
	<div class="row ">

                <div class="col-xl-8 col-lg-7">
		
<div class="card shadow mb-4 b">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Subject Overview</h6>
				<div class="float-right">
								<a href="subject_overview.php<?php echo '?id='.$get_id; ?>" class="btn btn-success"><i class="fas fa-arrow-left"></i> Back</a>
								</div>
                            </div>
							<?php 
								$subject_query = mysqli_query($conn,"select * from class_subject_overview where  class_subject_overview_id  = '$subject_id'")or die(mysqli_error());
								$subject_row = mysqli_fetch_array($subject_query);
								?>
							<div class="card-body">
								<center>
														<form class="form-horizontal" method="post">
																<div class="control-group">
																	<label class="control-label" for="inputPassword">Subject Overview Content:</label>
																	<div class="controls">
																			<textarea name="content" rows="5" cols="50" id="ckeditor_full"><?php echo $subject_row['content']; ?></textarea>
																	</div>
																</div>
														<div class="control-group">
														<div class="controls">
														
														<button name="save" type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save</button>
														</div>
														</div>
														</form>
										<?php
										if (isset($_POST['save'])){
										$content = $_POST['content'];
										mysqli_query($conn,"update class_subject_overview set content = '$content' where class_subject_overview_id = '$subject_id'")or die(mysqli_error());
										?>
										<script>
											window.location = 'subject_overview.php<?php echo '?id='.$get_id; ?>';
										</script>
										<?php
										}
										
										?>
											</center>
						                                </div>

						</div>
                        </div>
                        <!-- /block -->
            </div>
			</div>                    </div>
			</div>

		<?php include('admin/footer.php'); ?>
		</div>

		<?php include('script.php'); ?>
	
	