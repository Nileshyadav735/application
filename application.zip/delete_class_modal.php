<div id="delete<?php echo $id; ?>" class="fade modal" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Remove class</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
			Are you sure you want to Remove this  class?
		</div>
					
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i> Close</button>
	  <button name="remove" class="btn btn-danger remove" id="<?php echo $id; ?>" ><i class="fas fa-check icon-large"></i> Yes</button>

				</div>
    </div>
  </div>
</div> 
 




			
			

