<div style="width: 300px;  border: 3px;  padding-left: 5px;" class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Create Class</h6>
					</div>	
<form method="post"  id="add_class" >
										<div  class="form-group position-relative ">
											<label>Class Name:</label>
                                          <div class="controls">
											<input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
                                            <select name="class_id"  class="" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from class order by class_name");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option value="<?php echo $row['class_id']; ?>"><?php echo $row['class_name']; ?></option>
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
											<label>Subject:</label>
                                          <div class="controls">
                                            <select name="subject_id"  class="" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from subject order by subject_code");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option value="<?php echo $row['subject_id']; ?>"><?php echo $row['subject_code']; ?></option>
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
											<label>School Year:</label>
                                          <div class="controls">
											<?php
											$query = mysqli_query($conn,"select * from school_year order by school_year DESC");
											$row = mysqli_fetch_array($query);
											?>
											<select name="school_year" id="" class="span5" type="text" class="" name="school_year" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from school_year order by school_year DESC");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option><?php echo $row['school_year']; ?></option>
											<?php } ?>
                                            </select>
										 
										  </div>
                                        </div>
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="save" class="btn btn-success"><i class="fas fa-save"></i> Save</button>


										  </div>


                                        </div>
                                </form>
								<button class="btn btn-info v" onclick="openFormd(); myFunctiond()"><i class="fas fa-search fa-fw"></i>past class</button>



								<script>
function myFunctiond() {
  var elmnt = document.getElementById("myFormd");
  elmnt.scrollIntoView();
}
</script>

								<script src="admin/swal.js"></script>
            <script>
			jQuery(document).ready(function($){
				$("#add_class").submit(function(e){
					e.preventDefault();
					var _this = $(e.target);
					var formData = $(this).serialize();
					$.ajax({
						type: "POST",
						url: "add_class_action.php",
						data: formData,
						success: function(html){
						if(html=="true")
						{swal("Class Already Exist");
						}else{
							swal("Classs Successfully  Added");
							var delay = 500;
							setTimeout(function(){ window.location = 'dasboard_teacher.php'  }, delay);  
						}
						}
					});
				});
			});
			</script>		

								</div>
                            
                        </div>
