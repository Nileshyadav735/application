<div class="col-xl-4 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Add Downloadable</h6>
						
</div>
<div class="card-body b">

<form class="" id="add_downloadble" method="post" enctype="multipart/form-data" name="upload" >
                        <div class="form-group position-relative">
                            <label class="control-label" for="inputEmail">File:</label>
                            <div class="controls">
													
								<input name="uploaded_file"  class="input-file uniform_on" id="fileInput" type="file" required>
                         
                                <input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
                                <input type="hidden" name="id" value="<?php echo $session_id ?>"/>
                                <input type="hidden" name="id_class" value="<?php echo $get_id; ?>">
                            </div>
                        </div>
                        <div class="form-group position-relative">
                       
                            <div class="controls">
                                <input type="text" name="name" Placeholder="File Name"  class="input" required>
                            </div>
                        </div>
                        <div class="form-group position-relative">
                          
                            <div class="controls">
                                <input type="text" name="desc" Placeholder="Description"  class="input" required>
                            </div>
                        </div>
                        <div class="form-group position-relative">
                            <div class="controls">

                                <button name="Upload" type="submit" value="Upload" class="btn btn-info" /><i class="fas fa-upload"></i>&nbsp;Upload</button>
                            </div>
                        </div>
                    </form>
                    <div class="progress">
  <div class="progress-bar progress-bar" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
</div>
                    <script src="admin/swal.js"></script>

											<script>
            jQuery(document).ready(function($){
				$("#add_downloadble").submit(function(e){
                    e.preventDefault();
					var _this = $(e.target);
					var formData = new FormData($(this)[0]);
                    $.ajax({
						type: "POST",
						url: "upload_save_student.php",
						data: formData,
						success: function(html){
                            $(".progress-bar").animate({width: "100%"});
                            swal("Successfully  Added", { header: 'Student Added' });
setTimeout(() => {location.reload();
	}, 1000);
						},
						cache: false,
						contentType: false,
						processData: false
					});
				});
			});
			</script>	
							
        </div>
