<?php $get_id = $_GET['id']; ?>
<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id1 = $_POST['id'];?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Announcement</h1>
</div>
<div class="row">

<div class="col-xl-4 col-lg-7">
				<div class="card shadow mb-4">
		<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Announcements</h6>
				<div class="float-right">
				<a  class="btn btn-info" href="announcements.php<?php echo '?id='.$get_id; ?>"><i class="fas fa-arrow-left icon-large"></i> Back</a>
							
								</div>
                            </div>
							<div class="card-body b v">

							<form method="post">
									 <?php
								 $query_announcement = mysqli_query($conn,"select * from teacher_class_announcements
																	where teacher_id = '$session_id' and teacher_class_announcements_id = '$get_id1'  and  teacher_class_id = '$get_id' order by date DESC
																	")or die(mysqli_error());
								$row = mysqli_fetch_array($query_announcement);
								 $id = $row['teacher_class_announcements_id'];
								 ?>
								 <input type="hidden" name="id" value="<?php echo $id; ?>">
								<textarea name="content" id="">
								<?php echo $row['content']; ?>
								</textarea>
								<br>
								

</div>
<center>
								<button name="post" class="btn btn-info"><i class="fas fa-check icon-large"></i> Update</button>
								</center>
								</form>
								
									<?php
									if (isset($_POST['post'])){
									$content = $_POST['content'];
									$id = $_POST['id'];
									
									mysqli_query($conn,"update teacher_class_announcements  set content = '$content' where teacher_class_announcements_id = '$id' ")or die(mysqli_error());
									?>
									<script>
									 window.location = 'announcements.php<?php echo '?id='.$get_id; ?>'; 
									</script>
									<?php
									}
								?>

							</div>
							<script src="admin/swal.js"></script>

							<script type="text/javascript">
	$(document).ready( function() {

		
		$('.remove').click( function() {
		
		var id = $(this).attr("id");
			$.ajax({
			type: "POST",
			url: "remove_announcements.php",
			data: ({id: id}),
			cache: false,
			success: function(html){
			$("#del"+id).fadeOut('slow', function(){ $(this).remove();}); 
			$('#'+id).modal('hide');
			swal("Your Post is Successfully Deleted");
		
			}
			}); 
			
			return false;
		});				
	});

</script>
							</div>

							<?php include('admin/footer.php'); ?>

<?php include('script.php'); ?>
