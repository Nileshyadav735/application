<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('teacher_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">CHANGE PASSWORD</h1>
    
</div>


<style>
									.v,button{
								margin-left:10px;
								margin-top:10px;
								margin-bottom:10px;
								margin-right:10px;
								}</style>

<div class="col-xl-4 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Please Change Your Password</h6>             
				<?php
								$query = mysqli_query($conn,"select * from teacher where teacher_id = '$session_id'")or die(mysqli_error());
								$row = mysqli_fetch_array($query);
								?>	
		   </div>
					  <center>  <form  method="post" id="change_password" class="form-horizontal">
										<div class="form-group position-relative v">
											<label class="control-label" for="inputEmail">Current Password</label>
											<div class="controls">
											<input type="hidden" id="password" name="password" value="<?php echo $row['password']; ?>"  placeholder="Current Password">
											<input type="password" id="current_password" name="current_password"  placeholder="Current Password" required>
											</div>
										</div>
										<div class="form-group position-relative v">
											<label class="control-label" for="inputPassword">New Password</label>
											<div class="controls">
											<input type="password" id="new_password" name="new_password" placeholder="New Password" required>
											</div>
										</div>
										<div class="form-group position-relative v">
											<label class="control-label" for="inputPassword">Re-type Password</label>
											<div class="controls">
											<input type="password" id="retype_password" name="retype_password" placeholder="Re-type Password" required>
											</div>
										</div>
										<div class="form-group position-relative v">
											<div class="controls">
											<button type="submit" class="btn btn-info"><i class="fas fa-save"></i> Save</button>
											</div>
										</div>
									</form>
									</center>
						<script src="admin/swal.js"></script>
												<script>
			jQuery(document).ready(function(){
			jQuery("#change_password").submit(function(e){
					e.preventDefault();
						
						var password = jQuery('#password').val();
						var current_password = jQuery('#current_password').val();
						var new_password = jQuery('#new_password').val();
						var retype_password = jQuery('#retype_password').val();
						if (password != current_password)
						{
						swal({title:"FAIL" ,text:"Password does not match with your current password",icon:"error"});
						}else if  (new_password != retype_password){
						swal({title:"FAIL" ,text:"Retype password does not match with you new password" ,icon:"error"});
						}else if ((password == current_password) && (new_password == retype_password)){
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "update_password.php",
						data: formData,
						success: function(html){
					
						swal({title:"Success" ,text:"Your password Changed successfully", icon:"success"});
						var delay = 2000;
							setTimeout(function(){ window.location = 'dasboard_teacher.php'  }, delay);  
						
						}
						
						
					});
			
					}
				});
			});
			</script>
								
								</div>
									
								
									 
        
								
								<?php include('script.php'); ?>
									</div>                  
														
							
							
									<?php include('admin/footer.php'); ?>
							