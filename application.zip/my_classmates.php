<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('my_classmates_link.php'); ?>
<?php include('navbar_student.php'); ?>
<?php include('meeting.php'); ?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">CLASSMATES</h1>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="float-right">
                <a href="<?php echo $result->join_url ?>	" class="btn btn-danger"><i class="fas fa-camera"></i>
                    Join Meet</a>
            </div>
            <h6 class="m-0 font-weight-bold text-primary">YOUR CLASSMATES</h6>
        </div>
        <div class="card-body b">
            <!-- block -->
            <div class="table-responsive">

                <table cellpadding="0" cellspacing="0" border="0" width="100%" class="table" id="">

                    <thead>
                        <tr>
                            <th>PROFILE</th>
                            <th>NAME</th>




                        </tr>
                    </thead>


                    <tbody>
                        <?php				 
										 			$my_student = mysqli_query($conn,"SELECT *
														FROM teacher_class_student
														LEFT JOIN student ON student.student_id = teacher_class_student.student_id
														INNER JOIN class ON class.class_id = student.class_id where teacher_class_id = '$get_id' order by lastname ")or die(mysqli_error());
														
														while($row = mysqli_fetch_array($my_student)){
														$id = $row['teacher_class_student_id'];
														?>

                        <tr>
                            <td><img id="student_avatar_class" style="border-radius: 50%;"
                                    src="admin/<?php echo $row['location'] ?>" width="100" height="70"
                                    class="img-polaroid">
                            </td>
                            <td><?php echo $row['firstname']." ".$row['lastname'];  ?></td>

                        </tr>
                        <?php } ?>
                    </tbody>
                </table>


            </div>

        </div>
        <!-- /block -->





        <?php include('script.php'); ?>

    </div>

    <?php include('admin/footer.php'); ?>


    <!-- breadcrumb
<?php $query = mysqli_query($conn,"select * from teacher_class_student
					LEFT JOIN teacher_class ON teacher_class.teacher_class_id = teacher_class_student.teacher_class_id 
					JOIN class ON class.class_id = teacher_class.class_id 
					JOIN subject ON subject.subject_id = teacher_class.subject_id
					where student_id = '$session_id'
					")or die(mysqli_error());
					$row = mysqli_fetch_array($query);
					$id = $row['teacher_class_student_id'];	
					?>
					     