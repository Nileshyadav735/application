<?php $get_id = $_GET['id']; ?>
<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
 
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Subject Overview</h1>
   		 		</div>
					
	<div class="row ">

                <div class="col-xl-8 col-lg-7">
		
<div class="card shadow mb-4 b">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Subject Overview</h6>
				<div class="float-right">
									<?php $query = mysqli_query($conn,"select * from teacher_class
										LEFT JOIN class_subject_overview ON class_subject_overview.teacher_class_id = teacher_class.teacher_class_id
										where class_subject_overview.teacher_class_id = '$get_id'")or die(mysqli_error());
										$row = mysqli_fetch_array($query);
										$id = $row['class_subject_overview_id'];
										$count = mysqli_num_rows($query);
									if ($count > 0){
									?> <a href="edit_subject_overview.php<?php echo '?id='.$get_id; ?>&<?php echo 'subject_id='.$id; ?>" class="btn btn-info"><i class="fas fa-pen"></i> Edit Subject Overview</a>
									 <?php }else{ ?>
										     <a href="add_subject_overview.php<?php echo '?id='.$get_id; ?>" class="btn btn-success"><i class="fas fa-plus"></i> Add Subject Overview</a>
									 <?php } ?>
								</div>
                            </div>
                            <div class="card-body">
                               
										<?php echo $row['content']; ?>
                                </div>
								</div>
                        </div>
                        <!-- /block -->
            </div>
			</div>                    </div>
			</div>

		<?php include('admin/footer.php'); ?>
		</div>

		<?php include('script.php'); ?>
	
	