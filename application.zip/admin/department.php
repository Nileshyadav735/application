<?php include('header.php'); ?>

<div class="row">
<div class="col-xl-4 col-lg-7">
									
				<?php include('add_department.php'); ?>		   			
				</div>

			
				
				
				<div class="col-xl-8 col-lg-7">
	<div class="card shadow mb-4">
		<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
			<h6 class="m-0 font-weight-bold text-primary">LIST</h6>
			
		</div>
		<div class="card-body">
		<div class="table-responsive">

		<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
									<form action="delete_department.php" method="post">
									<a data-toggle="modal" href="#department_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash icon-large"></i></a>
									<?php include('modal_delete.php'); ?>
										<thead>
										  <tr>
												<th></th>
												<th>Department</th>
												<th>Person In-charge</th>
											
												<th></th>
										   </tr>
										</thead>
										<tbody>
													<?php
													$user_query = mysqli_query($conn,"select * from department")or die(mysqli_error());
													while($row = mysqli_fetch_array($user_query)){
													$id = $row['department_id'];
													?>
									
													<tr>
														<td width="30">
														<input id="optionsCheckbox"  name="selector[]" type="checkbox" value="<?php echo $id; ?>">
														</td>
														<td><?php echo $row['department_name']; ?></td>
														<td><?php echo $row['dean']; ?></td>
												
														<td width="30"><a href="edit_department.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="fas fa-pen"></i></a></td>

                               
													</tr>
												<?php } ?>
										</tbody>
									</table>
									</form>
                              
                
                </div>

</div>


						</div>
						</div>

							<?php include('footer.php'); ?>
	<?php include('script.php'); ?>
