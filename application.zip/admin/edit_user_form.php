<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">EDIT USER</h6>
            </div>
            <div class="card-body">
            
								<form method="post">

                <?php
								$query = mysqli_query($conn,"select * from users where user_id = '$get_id'")or die(mysqli_error());
								$row = mysqli_fetch_array($query);
								?>
										<div class="form-group position-relative">
                    <div class="controls">
                                            <input class="form-control input-lg rounded-0" value="<?php echo $row['firstname']; ?>" name="firstname" id="focusedInput" type="text" placeholder = "Firstname" required>
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" value="<?php echo $row['lastname']; ?>"  name="lastname" id="focusedInput" type="text" placeholder = "Lastname" required>
                                          </div>
                                        </div>
										
											<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" value="<?php echo $row['username']; ?>"  name="username" id="focusedInput" type="text" placeholder = "Username" required>
                                          </div>
                                        </div>
										
								
										
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="update" class="btn btn-success"><i class="fas fa-save"></i></button>
				<a href="admin_user.php" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add user</a>                     


                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
              
			<?php		
if (isset($_POST['update'])){

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];


mysqli_query($conn,"update users set username = '$username'  , firstname = '$firstname' , lastname = '$lastname' where user_id = '$get_id' ")or die(mysqli_error());

//mysqli_query($conn,"insert into activity_log (date,username,action) values(NOW(),'$user_username','Edit User $username')")or die(mysqli_error());
?>
<script>
  window.location = "admin_user.php"; 
</script>
<?php
}
?>