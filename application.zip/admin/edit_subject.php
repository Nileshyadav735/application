<?php include('header.php'); ?>
<?php $get_id = $_GET['id']; ?>

		<div class="row">
						<div class="col-xl-4 col-lg-7">
								
									<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">EDIT SUBJECT</h6>
            </div>
            <div class="card-body">
            
									<?php
									$query = mysqli_query($conn,"select * from subject where subject_id = '$get_id'")or die(mysqli_error());
									$row = mysqli_fetch_array($query);
									?>
									
									    <form class="form-horizontal" method="post">
										<div class="control-group">
											<label class="control-label" for="inputEmail">Subject Code</label>
											<div class="controls">
											<input type="text" value="<?php echo $row['subject_code']; ?>" name="subject_code" id="inputEmail" placeholder="Subject Code">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="inputPassword">Subject Title</label>
											<div class="controls">
											<input type="text" value="<?php echo $row['subject_title']; ?>" class="span8" name="title" id="inputPassword" placeholder="Subject Title" required>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="inputPassword">Number of Units</label>
											<div class="controls">
											<input type="text" value="<?php echo $row['unit']; ?>" class="span1" name="unit" id="inputPassword" required>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="inputPassword">Description</label>
											<div class="controls">
													<textarea name="description" id="">
													<?php echo $row['description']; ?>
													</textarea>
											</div>
										</div>
												
																		
											
										<div class="control-group">
										<div class="controls">
										
										<button name="update" type="submit" class="btn btn-info"><i class="fas fa-save icon-large"></i> </button>
										<a href="subjects.php" class="btn btn-info"><i class="fas fa-plus icon-large"></i> Add </a>

										</div>
										</div>
										</form>

										</div>
										</div>
										</div>
										
										<?php
										if (isset($_POST['update'])){
										$subject_code = $_POST['subject_code'];
										$title = $_POST['title'];
										$unit = $_POST['unit'];
										$description = $_POST['description'];
										
										
									
										mysqli_query($conn,"update subject set subject_code = '$subject_code' ,
																		subject_title = '$title',
																		unit  = '$unit',
																		description = '$description'
																		where subject_id = '$get_id' ")or die(mysqli_error());
																		
										mysqli_query($conn,"insert into activity_log (date,username,action) values(NOW(),'$user_username','Edit Subject $subject_code')")or die(mysqli_error());
										
										?>
										<script>
										window.location = "subjects.php";
										</script>
										<?php
										}
										
										
										?>




<div class="col-xl-8 col-lg-7">
	<div class="card shadow mb-4">
		<div
			class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
			<h6 class="m-0 font-weight-bold text-primary">SUBJECT LIST</h6>
			
		</div>

		<div class="card-body">
		<div class="table-responsive">

		<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
													
		<form action="delete_subject.php" method="post">
									<a data-toggle="modal" href="#subject_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash icon-large"> Delete</i></a>
									<?php include('modal_delete.php'); ?>
										<thead>
										  <tr>
											    <th></th>
												<th>Subject Code</th>
												<th>Subject Title</th>
												<th></th>
										   </tr>
										</thead>
										<tbody>
											
												<?php
											$subject_query = mysqli_query($conn,"select * from subject")or die(mysqli_error());
											while($row = mysqli_fetch_array($subject_query)){
											$id = $row['subject_id'];
											?>
										
											<tr>
													<td width="30">
													<input type="checkbox" id="optionsCheckbox"  class="" name="selector[]"  value="<?php echo $id; ?>">
													</td>
													<td><?php echo $row['subject_code']; ?></td>
													<td><?php echo $row['subject_title']; ?></td>
												
													<td width="30"><a href="edit_subject.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="fas fa-pen"></i> </a></td>
										</tr>
											
											<?php } ?>   
                              
										</tbody>
									</table>
									</form>				
								
		                            </div>
		                        </div>
		                    </div>
		                </div>
		<?php include('footer.php'); ?>
    
		<?php include('script.php'); ?>
   