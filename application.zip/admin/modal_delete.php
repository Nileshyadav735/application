					<!-- user delete modal -->
					<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="user_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Users?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the Users.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_user" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 
	
					<!-- department delete modal -->
					<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="department_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Department?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the Department.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_department" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 

					<!-- class delete modal -->
						<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="class_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Class?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the class you check?.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_class" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 
 



											<!-- student delete modal -->
				<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="student_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Student?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the student you check?.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_student" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 
 

					
					
											<!-- student delete modal -->
					<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="teacher_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Teacher?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the teacher you check?.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_teacher" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 
					
					                 	<!-- Content delete modal -->
					<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="content_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Content?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the Content you check?.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_content" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 
					
					
					
					<!-- Content delete modal -->
					<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="subject_delete">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete subject?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <div class="alert alert-danger">
					<p>Are you sure you want to delete the subject you check?.</p>
					</div>
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-remove"></i> Close</button>
	  <button name="delete_subject" class="btn btn-danger"><i class="fas fa-check"></i> Yes</button>
		</div>
    </div>
  </div>
</div> 					