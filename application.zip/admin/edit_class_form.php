<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">EDIT CLASS</h6>
            </div>
            <div class="card-body">
							<?php
							$query = mysqli_query($conn,"select * from class where class_id = '$get_id'")or die(mysqli_error());
							$row = mysqli_fetch_array($query);
							?>
                            
								<form method="post">
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input name="class_name" value="<?php echo $row['class_name']; ?>" class="input focused" id="focusedInput" type="text" placeholder = "Class Name" required>
                                          </div>
                                        </div>
										
									
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="update" class="btn btn-success"><i class="fas fa-save icon-large"></i></button>
                                                <a href="class.php" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add class</a>                     

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                       
                           <?php
if (isset($_POST['update'])){
$class_name = $_POST['class_name'];

mysqli_query($conn,"update class set class_name = '$class_name' where class_id = '$get_id' ")or die(mysqli_error());
?>

<script>
window.location = "class.php";
</script>
<?php

}
?>