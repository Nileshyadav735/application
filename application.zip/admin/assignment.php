<?php include('header.php'); ?>
<div class="col-xl-9 col-lg-7">
	<div class="card shadow mb-4">
		<!-- Card Header - Dropdown -->
		<div
			class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
			<h6 class="m-0 font-weight-bold text-primary">ASSIGNMENT</h6>
			
		</div>
		<div class="table-responsive">

		<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
						
										<thead>
										        <tr>

												<th>File Name</th>
												<th>Description</th>
												<th>Date Upload</th>
												<th>Upload By</th>
												<th>Class</th>
                                   
												</tr>
												
										</thead>
										<tbody>
											
                              		<?php
										$query = mysqli_query($conn,"select * FROM assignment LEFT JOIN teacher ON teacher.teacher_id = assignment.teacher_id 
																				    ")or die(mysqli_error());
										$query1 = mysqli_query($conn,"select * FROM assignment LEFT JOIN class ON class.class_id = assignment.class_id 
																				    ")or die(mysqli_error());
																					$rowa = mysqli_fetch_array($query1);
											
                                                                                    //LEFT JOIN teacher_class ON teacher_class.teacher_class_id = assignment.class_id 
																				  //INNER JOIN class ON class.class_id = teacher_class.class_id
										while($row = mysqli_fetch_array($query)){
									?>
							

					
                              
										<tr>

                                         <td><?php  echo $row['fname']; ?></td>
                                         <td><?php echo $row['fdesc']; ?></td>
                                         <td><?php echo $row['fdatein']; ?></td>
                                         <td><?php echo $row['firstname']." ".$row['lastname']; ?></td>
                                         <td><?php echo $rowa['class_name']; ?></td>

                               
                                </tr>
                         
						 <?php } ?>
						   
                              
										</tbody>
									</table>
									</div>
                                    </div>
                            </div>
                      
		<?php include('footer.php'); ?>
    
		<?php include('script.php'); ?>
   