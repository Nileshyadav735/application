<?php
define('API_KEY','eGkRGTXmSqy4fdmwgRCRxQ');
define('API_SECRET','OSGlFLwYrQmxh8SzZGuBpUaP2yeZqz3n2dOy');
define('EMAIL_ID','nileshyadav735@gmail.com');
?>