<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">ADD CLASS</h6>
            </div>
            <div class="card-body">
								<form method="post">
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input name="class_name" id="class_name" class="input focused" id="focusedInput" type="text" placeholder = "Class Name" required>
                                          </div>
                                        </div>
										
									
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="save" class="btn btn-info"><i class="fas fa-plus icon-large"></i></button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                        <?php
if (isset($_POST['save'])){
$class_name = $_POST['class_name'];


$query = mysqli_query($conn,"select * from class where class_name  =  '$class_name' ")or die(mysqli_error());
$count = mysqli_num_rows($query);

if ($count > 0){ ?>

<script>
swal({title:"Fail" ,text:"Data Already exist", icon:"error"});
</script>
<?php
}else{
mysqli_query($conn,"insert into class (class_name) values('$class_name')")or die(mysqli_error());
?>
<script>
window.location = "class.php";
</script>
<?php
}
}
?>