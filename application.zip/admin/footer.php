<style>
.footer {
   position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
     text-align: center;
}
</style>
 <!-- Footer -->
 <footer class="sticky-footer bg-white footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy;TEIT PROJECT</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->