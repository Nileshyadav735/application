  <div class="card shadow mb-4">
              <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">ADD USER</h6>
              </div>
              <div class="card-body">
                  <form method="post">
										<div class="form-group position-relative">
                    <div class="controls">

                                            <input class="form-control input-lg rounded-0" name="firstname" id="focusedInput" type="text" placeholder = "Firstname" required>
                                            </div>
                                        </div>
										
										<div class="form-group position-relative">
                    <div class="controls">

                                            <input class="form-control input-lg rounded-0" name="lastname" id="focusedInput" type="text" placeholder = "Lastname" required>
                                            </div>
                                        </div>
										
											<div class="form-group position-relative">
                                         
                      <div class="controls">

                                            <input class="form-control input-lg rounded-0" name="username" id="focusedInput" type="text" placeholder = "Username" required>
                                            
                                            </div>
                                        </div>
										
										<div class="form-group position-relative">
                    <div class="controls">
                 
                                            <input class="form-control input-lg rounded-0" name="password" id="focusedInput" type="text" placeholder =  "password" required>
                                          
                                           
                                            </div>
                                        </div>
										
											<div class="text-center my-4">
                      <div class="controls">

                      <button  name="save"  class="btn btn-danger px-3"><i class="fas fa-plus" aria-hidden="true"></i>Add User</button>
                      </div> 
                                        </div>
                                </form>
                                </div>
        </div>


					
					<?php
if (isset($_POST['save'])){
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$password = $_POST['password'];
$pass=$password;

$pass_enc=password_hash($pass,PASSWORD_BCRYPT);
$query = mysqli_query($conn,"select * from users where username = '$username' and firstname = '$firstname'")or die(mysqli_error());
$count = mysqli_num_rows($query);

if ($count > 0){ ?>
<script>
swal({title:"Fail" ,text:"User Name Not Available" ,icon:"error"});
</script>
<?php
}else{
mysqli_query($conn,"insert into users (username,password,firstname,lastname) values('$username','$pass_enc','$firstname','$lastname')")or die(mysqli_error());


?>
<script>
window.location = "admin_user.php";
</script>
<?php
}
}
?>

<div><?php  ?></div>