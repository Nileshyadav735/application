<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">ADD SUBJECT</h6>
            </div>
            <div class="card-body">  
			<form class="form-horizontal" method="post">
										<div class="form-group position-relative">
											<label class="control-label" for="inputEmail">Subject Code</label>
											<div class="controls">
											<input type="text" class="form-control input-lg rounded-500" name="subject_code" id="inputEmail" placeholder="Subject Code" required>
											</div>
										</div>
										<div class="form-group position-relative">
											<label class="control-label" for="inputPassword">Subject Title</label>
											<div class="controls">
											<input type="text" class="form-control input-lg rounded-500" name="title" id="inputPassword" placeholder="Subject Title" required>
											</div>
										</div>
										<div class="form-group position-relative">
											<label class="control-label" for="inputPassword">Number of Units</label>
											<div class="controls">
											<input type="text" class="form-control input-lg rounded-500" name="unit" id="inputPassword" required>
											</div>
										</div>
											<div class="form-group position-relative">
											<label class="control-label" for="inputPassword">Semester</label>
											<div class="controls">
												<select  class="fas fa-caret-down" name="semester">
													<option></option>
													<option>1st</option>
													<option>2nd</option>
													<option>3rd</option>
													<option>4th</option>
													<option>5th</option>
													<option>6th</option>
													<option>7th</option>
													<option>8th</option>
												</select>
											</div>
										</div>
								
										<div class="form-group position-relative">
											<label class="control-label" for="inputPassword">Description</label>
											<div class="controls">
													<textarea name="description" class="form-control input-lg rounded-500" id=""></textarea>
											</div>
										</div>
												
																		
											
										<div class="form-group position-relative">
										<div class="controls">
										
										<button name="save" type="submit" class="btn btn-info"><i class="icon-save"></i> Save</button>
										</div>
										</div>
										</form>
										</div>
										</div>
										
										<?php
										if (isset($_POST['save'])){
										$subject_code = $_POST['subject_code'];
										$title = $_POST['title'];
										$unit = $_POST['unit'];
										$description = $_POST['description'];
										$semester = $_POST['semester'];
										
										
										$query = mysqli_query($conn,"select * from subject where subject_code = '$subject_code' ")or die(mysqli_error());
										$count = mysqli_num_rows($query);

										if ($count > 0){ ?>
										<script>
										swal({title:"Fail" ,text:"Data Already exist", icon:"error"});
										</script>
										<?php
										}else{
										mysqli_query($conn,"insert into subject (subject_code,subject_title,description,unit,semester) values('$subject_code','$title','$description','$unit','$semester')")or die(mysqli_error());
										?>
										<script>
										window.location = "subjects.php";
										</script>
										<?php
										}
										}
										
										?>
									
								