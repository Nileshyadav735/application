<?php include('header.php'); ?>
<div class="row"	>
<div class="col-xl-10 col-lg-8">
	<div class="card shadow mb-4">
		<!-- Card Header - Dropdown -->
		<div
			class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
			<h6 class="m-0 font-weight-bold text-primary">FILES</h6>
			
		</div>
		<div class="table-responsive">
		<div class="card-body b">

		<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
						
										<thead>
										        <tr>
												<th>Date Upload</th>
												<th>File Name</th>
												<th>Description</th>
												<th>Upload By</th>
												<th>Class</th>
                                   
												</tr>
												
										</thead>
										<tbody>
											
                              		<?php
										$query = mysqli_query($conn,"select * FROM files LEFT JOIN teacher ON teacher.teacher_id = files.teacher_id ")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
									?>
										<tr>
										 <td><?php echo $row['fdatein']; ?></td>
                                         <td><a href="../<?php  echo $row['floc']; ?>"><?php  echo $row['fname']; ?> </a> </td>
                                         <td><?php echo $row['fdesc']; ?></td>                                      
                                         <td><?php echo $row['uploaded_by']." ".$row['lastname']; ?></td>
                                         <td><?php echo $row['class_id']; ?></td>

                               
                                </tr>
                         
						 <?php } ?>
						   
                              
										</tbody>
									</table>

									
									</div>
									
                                </div>
							
                                </div>
                                </div>

							</div>
			

							
                      
		<?php include('footer.php'); ?>
    
		<?php include('script.php'); ?>
		
   