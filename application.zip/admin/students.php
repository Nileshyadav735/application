<?php include('header.php'); ?>
<div class="row">

    <!-- Area Chart -->
                    <div class="col-xl-4 col-lg-7">
                           <div class="card shadow mb-4">
                              <?php include('add_students.php'); ?>		   			

                     </div>
                         </div>
			
                         <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">


		<div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">STUDENTS LIST</h6>
            </div>
			<div class="table-responsive">

								
									<form action="delete_student.php" method="post">
									<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
    <div class="form-group position-relative">
	<a data-toggle="modal" href="#student_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash"> DELETE</i></a>
    </div>
	<div class="pull-right">
			   
	</div>
	<?php include('modal_delete.php'); ?>
		<thead>
		<tr>
					<th></th>
				
					<th>Name</th>
					<th>PRN Number</th>
			
					
		</tr>
		</thead>
		<tbody>
			
		<?php
	$query = mysqli_query($conn,"select * from student") or die(mysqli_error());
	while ($row = mysqli_fetch_array($query)) {
		$id = $row['student_id'];
		?>
	
		<tr>
		<td width="30">
		<input id="optionsCheckbox" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
		</td>
	
		<td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td> 
		<td><?php echo $row['username']; ?></td> 
	
		
	
		<td width="30"><a href="edit_student.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="fas fa-pen"></i> </a></td>
	
		</tr>
	<?php } ?>    
	
		</tbody>
	</table>
	</form>
                                    </div>

</div>
</div>
</div>
		<?php include('footer.php'); ?>
		<?php include('script.php'); ?>
