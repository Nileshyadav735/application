<?php include('header.php'); ?>
<?php $get_id = $_GET['id']; ?>

<div class="row">

    <!-- Area Chart -->
                    <div class="col-xl-4 col-lg-7">
                          <?php include('edit_teacher_form.php'); ?>		   			
				</div>
                

                
                                       
                         <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
        <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">TEACHERS LIST</h6>
            </div>
            <div class="table-responsive">

  									<form action="delete_teacher.php" method="post">
                                      <table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
									
                                
                                            <a data-toggle="modal" href="#teacher_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash icon-large"> Delete</i></a>
                                     
                                    
                                    <?php include('modal_delete.php'); ?>
										<thead>
										    <tr>
                                    <th></th>
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Username</th>

                                    <th></th>
                                </tr>
										</thead>
										<tbody>
												 <?php
                                    $teacher_query = mysqli_query($conn,"select * from teacher") or die(mysqli_error());
                                    while ($row = mysqli_fetch_array($teacher_query)) {
                                    $id = $row['teacher_id'];
                                        ?>
									<tr>
										<td width="30">
										<input id="optionsCheckbox"  name="selector[]" type="checkbox" value="<?php echo $id; ?>" required>
										</td>
                                    <td width="40"><img class="img-rounded" src="<?php echo $row['location']; ?>" height="50" width="50"></td> 
                                    <td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td> 
                                    <td><?php echo $row['username']; ?></td> 
                               
									<td width="30"><a href="edit_teacher.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="fas fa-pen"></i></a></td>
                                </tr>
                            <?php } ?>
                               
										</tbody>
									</table>
									</form>
                                
                    </div>


                </div>
            </div>
                                    </div>
		<?php include('footer.php'); ?>
        
		<?php include('script.php'); ?>
