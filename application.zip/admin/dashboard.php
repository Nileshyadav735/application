<?php include('header.php'); ?>

<!-- Begin Page Content -->
 <div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    
</div>

<!-- Content Row -->
<div class="row flex flex-wrap">

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            TEACHERS</div>
                            <?php 
								$query_teacher = mysqli_query($conn,"select * from teacher")or die(mysqli_error());
								$count_teacher = mysqli_num_rows($query_teacher);
								?>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count_teacher ?></div>
                    </div>
                    <div class="col-auto">
                        <a href="teachers.php" >  <i class="fas fa-calendar fa-2x text-gray-300"></i> </a>
                    </div>
                </div>
                        </div>
        </div>
    </div>

   
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            STUDENT</div>
                            <?php 
								$query_student = mysqli_query($conn,"select * from student")or die(mysqli_error());
								$count_student = mysqli_num_rows($query_student);
								?>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count_student ?></div>
                    </div>
                    <div class="col-auto">
                    <a href="students.php" > <i class="fas fa-user-circle fa-2x text-gray-300"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            CLASS</div>
                            <?php 
								$query_class = mysqli_query($conn,"select * from class")or die(mysqli_error());
								$count_class = mysqli_num_rows($query_class);
								?>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count_class; ?></div>
                    </div>
                    <div class="col-auto">
                    <a href="class.php" > <i class="fa fa-university fa-2x text-gray-300"></i> </a>
                    </div>
                </div>
            </div>
        </div>
    </div> 


    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Files
                        </div>
                        <?php 
								$query_file = mysqli_query($conn,"select * from files")or die(mysqli_error());
								$count_file = mysqli_num_rows($query_file);
								?>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $count_file; ?></div>
                            </div>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar"
                                        style="width: <?php echo $count_file; ?>" aria-valuenow="50" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                    <a href="downloadable.php" > <i class="fas fa-clipboard-list fa-2x text-gray-300"></i> </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            SUBJECTS</div>
                            <?php 
								$query_subject = mysqli_query($conn,"select * from subject")or die(mysqli_error());
								$count_subject = mysqli_num_rows($query_subject);
								?>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count_subject; ?></div>
                    </div>
                    <div class="col-auto">
                    <a href="subjects.php" >  <i class="fas fa-universal-access fa-2x text-gray-300"></i> </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Content Row -->

<div class="row">

<style>
div.b
{
    height:400px;
  overflow: scroll;
}

</style>
    <!-- Area Chart -->
    <div class="col-xl-6 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">User Log</h6>
    
            </div>
            <!-- Card Body -->
            <div class="card-body b">
           
           
            <div class="table-responsive">

            <table cellpadding="0" cellspacing="0" border="0" width="100%"  class="table table-bordered" id="example dataTable" >
								
                                <thead>
                                  <tr>
                                  <th>Username</th>
                                        <th>Login</th>
                                        <th>logout</th>
                                        
                                        
                                    
                                   </tr>
                                </thead>
                                <tfoot>
                                        <tr>
                                        <th>Username</th>
                                        <th>Login</th>
                                        <th>logout</th>                                      
                                        </tr>
                                    </tfoot>



                                <tbody>
                                            <?php
                                            $user_query = mysqli_query($conn,"select * from user_log order by user_log_id  DESC")or die(mysqli_error());
                                            while($row = mysqli_fetch_array($user_query)){
                                            $id = $row['user_log_id'];
                                            ?>
                            
                                        <tr>
                                        <td><?php echo $row['username']; ?></td>
                                        <td><?php echo $row['login_date']; ?></td>
                                        <td><?php echo $row['logout_date']; ?></td>
                                        
                                        </tr>
                                        <?php } ?>
                                </tbody>
                            </table>
                
            </div>
        </div>
    </div>
                                            </div>





<div class="col-xl-6 col-lg-7">
                                                

        <!-- Approach -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Activity log</h6>
            </div>
            <div class="card-body b">
            <div id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                
                            <div class="table-responsive">
  									<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
						
										<thead>
										        <tr>

												<th>Date</th>
												<th>User</th>
												<th>Action</th>
									
												</tr>
												
										</thead>
										<tbody>
											
                              		<?php
										$query = mysqli_query($conn,"SELECT * FROM activity_log ORDER BY activity_log_id DESC")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
									?>
							

					
                              
										<tr>

                                         <td><?php  echo $row['date']; ?></td>
                                         <td><?php echo $row['username']; ?></td>
                                         <td><?php echo $row['action']; ?></td>
                                  
                               
                                </tr>
                         
						 <?php } ?>
						   
                              
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>
            </div>
        </div>

    </div>
        </div>

    </div>

    </div>  
        


           

        </div>
            

    </div>
    

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

   

 


                                            

    <?php include('script.php'); ?>
</body>

</html>