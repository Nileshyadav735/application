<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">EDIT DEPARTMENT</h6>
            </div>
            <div class="card-body">
							<?php 
							$query = mysqli_query($conn,"select * from department where department_id = '$get_id'")or die(mysqli_error());
							$row = mysqli_fetch_array($query);
							?>
            
								<form method="post">
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" value="<?php echo $row['department_name']; ?>" id="focusedInput" name="dn" type="text" placeholder = "Deparment" require>
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" value="<?php echo $row['dean']; ?>" id="focusedInput" name="d" type="text" placeholder = "Person Incharge">
                                          </div>
                                        </div>
								
										
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="update" class="btn btn-success"><i class="fas fa-save icon-large"></i></button>
                        <a href="department.php" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add Department</a>
                                          </div>
                                        </div>
                </form>
                                </div>
                            </div>
                       
					
 <?php
 if (isset($_POST['update'])){
 

 $dn = $_POST['dn'];
 $d = $_POST['d'];
 
 mysqli_query($conn,"update department set department_name = '$dn' , dean  = '$d' where department_id = '$get_id' ")or die(mysqli_error());
 ?>
 <script>
 window.location='department.php'; 
 </script>
 <?php 
 }
 ?>
 