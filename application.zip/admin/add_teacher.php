<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">ADD TEACHER</h6>
            </div>
            <div class="card-body">
								<form method="post">
							
										
										  <div class="form-group position-relative">
											<label>Department:</label>
                                          <div class="form-group position-relative">
                                            <select name="department"  class="fa fa-caret-down"  required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from department order by department_name");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option value="<?php echo $row['department_id']; ?>"><?php echo $row['department_name']; ?></option>
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" name="firstname" id="focusedInput" type="text" placeholder = "Firstname">
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" name="lastname" id="focusedInput" type="text" placeholder = "Lastname">
                                          </div>
                                        </div>
										
										
									
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="save" class="btn btn-info"><i class="fas fa-plus"></i></button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                       <?php
                            if (isset($_POST['save'])) {
                           
                                $firstname = $_POST['firstname'];
                                $lastname = $_POST['lastname'];
                                $department_id = $_POST['department'];
								
								
								$query = mysqli_query($conn,"select * from teacher where firstname = '$firstname' and lastname = '$lastname' ")or die(mysqli_error());
								$count = mysqli_num_rows($query);
								
								if ($count > 0){ ?>
								<script>
								swal({title:"Fail" ,text:"User Already Available" ,icon:"error"});
								</script>
								<?php
								}else{

                                mysqli_query($conn,"insert into teacher (firstname,lastname,location,department_id)
								values ('$firstname','$lastname','uploads/NO-IMAGE-AVAILABLE.jpg','$department_id')         
								") or die(mysqli_error()); ?>
								<script>
							 	window.location = "teachers.php"; 
								</script>
								<?php   }} ?>
						 
						 