<?php include('header.php'); ?>
<?php $get_id = $_GET['id']; ?>

<div class="row">
		<div class=" col-xl-8  card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">EDIT CONTENT</h6>
            </div>
            <div class="card-body b">
   								<a class="btn btn-info v" href="content.php"><i class="fas fa-arrow-left"></i> Back</a>
									   <?php
									   $query = mysqli_query($conn,"select * from content where content_id = '$get_id'")or die(mysqli_error());
									   $row = mysqli_fetch_array($query);
									   ?>
									   
									   <form class="form-horizontal" method="POST">
										<div class="form-group position-relative">
										<label class="control-label" for="inputEmail">Title</label>
										<div class="form-group">
										<input type="text"  class="form-group" name="title" id="inputEmail" placeholder="Title" value="<?php echo $row['title']; ?>">
										</div>
										</div>
										
												
										<label class="control-label" for="inputPassword">Content</label>
									
										<div class="controls">
							
							<center>	
							<textarea class="v b" name="contentadmin" id="" rows="10" placeholder="Start Typing Here......." cols="50"><?php echo $row['content']; ?></textarea>
							<center>
                            </div> 
		
            										<div class="form-group position-relative">
										<div class="controls">
										
										<button name="update" type="submit" class="btn btn-info"><i class="icon-save icon-large"></i> Update</button>
										</div>
										</div>
										</form>
										
										<?php
										if (isset($_POST['update'])){
										$title = $_POST['title'];
										$content = $_POST['contentadmin'];
										mysqli_query($conn,"update content set title = '$title' , content = '$content' where content_id = '$get_id'")or die(mysqli_error());
										?>
										<script>
										window.location = 'content.php';
										</script>
										<?php
										}
										?>
									
								
		                            </div>
		                        </div>
                    </div>


                </div>


				
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>

</html>