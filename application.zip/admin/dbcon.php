<?php
$conn = mysqli_connect('localhost','root','uRs8HVMgUx7c','campus') or die(mysqli_error());
?>