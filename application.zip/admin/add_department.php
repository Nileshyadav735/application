<div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">ADD DEPARTMENT</h6>
            </div>
            <div class="card-body">
								<form method="post">
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" id="focusedInput" name="d" type="text" placeholder = "Deparment" required>
                                          </div>
                                        </div>
										
										<div class="form-group position-relative">
                                          <div class="controls">
                                            <input class="form-control input-lg rounded-0" id="focusedInput" name="pi" type="text" placeholder = "Person Incharge" required>
                                          </div>
                                        </div>
								
										
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="save" class="btn btn-info"><i class="fas fa-plus"> Add</i></button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                       
					<?php
if (isset($_POST['save'])){
$pi = $_POST['pi'];
$d = $_POST['d'];


$query = mysqli_query($conn,"select * from department where department_name = '$d' and dean = '$pi' ")or die(mysqli_error());
$count = mysqli_num_rows($query);

if ($count > 0){ ?>
<script>
swal({title:"Fail" ,text:"Data Already exist", icon:"error"});
</script>
<?php
}else{
mysqli_query($conn,"insert into department (department_name,dean) values('$d','$pi')")or die(mysqli_error());
?>
<script>
window.location = "department.php";
</script>
<?php
}
}
?>