<?php include('header.php'); ?>


<div class="row">
    <div class="col-xl-4 col-lg-7">
        <?php include('add_teacher.php'); ?>
    </div>



    <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">TEACHERS LIST</h6>
            </div>
            <div class="table-responsive">

                <form action="delete_teacher.php" method="post">
                    <table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered"
                        id="example">
                        <a data-toggle="modal" href="#teacher_delete" id="delete" class="btn btn-danger v" name=""><i
                                class="fa fa-trash"> Delete</i></a>
                        <?php include('modal_delete.php'); ?>
                        <thead>
                            <tr>
                                <th></th>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Username</th>

                                <th>edit</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                    $teacher_query = mysqli_query($conn,"select * from teacher") or die(mysqli_error());
                                    while ($row = mysqli_fetch_array($teacher_query)) {
                                    $id = $row['teacher_id'];
                                    $teacher_stat = $row['status'];
                                        ?>
                            <tr>
                                <td width="30">
                                    <input id="optionsCheckbox" name="selector[]" type="checkbox"
                                        value="<?php echo $id; ?>">
                                </td>
                                <td width="40"><img class="img-circle" alt="pic" src="<?php echo $row['location']; ?>"
                                        height="50" width="50"></td>
                                <td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td>
                                <td><?php echo $row['username']; ?></td>

                                <td width="50"><a href="edit_teacher.php<?php echo '?id='.$id; ?>"
                                        class="btn btn-success"><i class="fas fa-pen"></i></a></td>
                                <td width="50">
                                    <?php
					if($row['status']==1){
                        ?><div class="custom-control custom-switch" id="here">
                                        <input type="checkbox" class="custom-control-input"
                                            <?php echo $row['status'] == '1' ? 'checked' : '' ;?> />
                                        <label class="custom-control-label" for="<?php echo $row['teacher_id']?>">

                                            <?php echo "<a  href='?id=".$row['teacher_id']."&type=deactive'>Active</a>";?>
                                        </label>


                                    </div>
                                    <?php
					}else{
                         ?>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" id="<?php echo $row['teacher_id']?>" name="onoffswitch"
                                            value="<?php echo $row['teacher_status']?>" class="custom-control-input"
                                            <?php echo $row['status'] == '1' ? 'checked' : '' ;?> />
                                        <label class="custom-control-label" for="<?php echo $row['teacher_id']?>"><?php 
  
  echo "<a onClick='updateDIV()' href='?id=".$row['teacher_id']."&type=active'>Deactive</a>";
  ?>
                                        </label>


                                    </div>
                                    <?php
					}
					?>
                                </td>


                            </tr>
                            <?php } ?>

                        </tbody>
                    </table>
                </form>



            </div>

        </div>
    </div>


    <div>

    </div>
    <?php include('footer.php'); ?>
    <?php include('script.php'); ?>
    <?php
if(isset($_GET['id'])){
	$id=mysqli_real_escape_string($conn,$_GET['id']);
	$type=mysqli_real_escape_string($conn,$_GET['type']);
	if($type=='active'){
		$status=1;
	}else{
		$status=0;
	}
	$done=mysqli_query($conn,"update teacher set status = '$status'  where teacher_id = '$id' ");
if($done){
    ?>
    <script src="admin/swal.js"></script>

    <script>
    function myFunction() {

        window.location = 'teachers.php';
    }
    myFunction();
    </script>





    <?php
}
}
?>