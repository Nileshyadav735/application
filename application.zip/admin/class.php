<?php include('header.php'); ?>
<div class="row">
				<div class="col-xl-4 col-lg-7">
									
				<?php include('add_class.php'); ?>		   			
			
				</div>



				<div class="col-xl-8 col-lg-7">
	<div class="card shadow mb-4">
		<!-- Card Header - Dropdown -->
		<div
			class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
			<h6 class="m-0 font-weight-bold text-primary">CLASS LIST</h6>
			
		</div>
		<!-- Card Body -->
		<div class="card-body">
		<div class="table-responsive">

		<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
			
									<form action="delete_class.php" method="post">
									<table cellpadding="0" cellspacing="0" border="0" width="100%" class="table table-bordered" id="example dataTable" >
										<a data-toggle="modal" href="#class_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash icon-large"> Delete</i></a>
													<?php include('modal_delete.php'); ?>
									<thead>
															  <tr>
													<th></th>
													<th>Course Year And Section</th>
													<th></th>
										   </tr>
										</thead>
										<tbody>
										<?php
										$class_query = mysqli_query($conn,"select * from class")or die(mysqli_error());
										while($class_row = mysqli_fetch_array($class_query)){
										$id = $class_row['class_id'];
										?>
												
										<tr>
											<td width="30">
											<input id="optionsCheckbox" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
											</td>
											<td><?php echo $class_row['class_name']; ?></td>
											<td width="40"><a href="edit_class.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="fas fa-pen icon-large"></i> </a></td>
                                     
                               
										</tr>
										<?php } ?>
                               
                               
										</tbody>
									</table>
									</form>
													</div>
													
						</table>
			
		</div>
				</div>
		</div>

		


</div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
