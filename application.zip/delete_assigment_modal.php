<div id="del<?php echo $id; ?>" class="fade modal" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Delete Assignment</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	 	
	  <div class="alert alert-danger">
			Are you sure you want to delete this Assignment?
		</div>		
										
      </div>
      <div class="modal-footer">
	  <form method="post" action="delete_assignment.php">
		<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i> Close</button>
		<input type="hidden" name="id" value="<?php echo $id; ?>">
		<input type="hidden" name="get_id" value="<?php echo $get_id; ?>">
		<button class="btn btn-danger" name="change"><i class="fas fa-check icon-large"></i> Yes</button>
		</form>
				</div>
    </div>
  </div>
</div> 
 