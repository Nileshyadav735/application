<div class="card-body">
								 			    <ul class="nav nav-tabs">
										<li class="btn btn-outline-primary v">
											<a href="student_message.php">For Teacher</a>
										</li>
										<li  class="btn btn-outline-primary v"><a href="student_message_student.php">For Student</a></li>
									</ul>
								
						

								<form method="post" id="send_message_student">
									<div class="control-group">
											<label>To:Select student</label>
                                          <div class="controls">
                                            <select name="student_id"  class="chzn-select" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from student order by firstname ASC");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option value="<?php echo $row['student_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?> </option>
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
										
										<div class="control-group">
											<label>Content:</label>
                                          <div class="controls">
											<textarea name="my_message" class="my_message" required></textarea>
                                          </div>
                                        </div>
										<div class="control-group">
                                          <div class="controls">
												<button  class="btn btn-success"><i class="fas fa-paper-plane"></i> Send </button>

                                          </div>
                                        </div>
                                </form>
  
												<script>
															jQuery(document).ready(function(){
															jQuery("#send_message_student").submit(function(e){
																	e.preventDefault();
																	var formData = jQuery(this).serialize();
																	$.ajax({
																		type: "POST",
																		url: "send_message_student_to_student.php",
																		data: formData,
																		success: function(html){
																			swal({  text: "Message Successfully Sended",
																			 icon :"success"});
																		var delay = 1000;
																			setTimeout(function(){ window.location = 'student_message_student.php'  }, delay);  
																		}
																	});
																	return false;
																});
															});
												</script>
								
								
								</div>
                            </div>
                        </div>
                        <!-- /block -->
						

	</div>
</div>