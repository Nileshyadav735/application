<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('student_sidebar.php'); ?>
<?php include('navbar_student.php'); ?>
<div class="container-fluid">
				
				<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">MESSAGES</h1>
   		 		</div>
	<div class="row">

                <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Your Message</h6>
					</div>		
					<style>
									.v,button{
								margin-left:10px;
								margin-top:10px;
								margin-bottom:10px;

								}</style>
								                      
										
										<ul class="nav nav-pills ">
										<li class="btn btn-outline-primary v"><a href="student_message.php"><i class="fas fa-envelope fa-fw"></i>inbox</a></li>
										<li class="v"><a href="sent_message_student.php"><i class="fas fa-envelope fa-fw"></i>Sent messages</a></li>
										</ul>
										<hr>



										<div class="card-body b">
                        <!-- block -->
                        <div class="table-responsive">

						<form action="read_message.php" method="post">
										<div class="pull-right">
											<button class="btn btn-info" name="read"><i class="fas fa-check"></i> Read</button>
													
							Check All <input type="checkbox"  name="selectAll" id="checkAll" />
								<script>
								$("#checkAll").click(function () {
									$('input:checkbox').not(this).prop('checked', this.checked);
								});
								</script>					
							
						<div class="post"  id="<?php echo $id; ?>">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"  class="table table-bordered" id="example dataTable" >
								
                                <thead>
                                  <tr>
                                  <th>Message</th>
                                        <th>From</th>
                                        <th><i class="fas fa-clock"></i>Time</th>
                                        <th>Reply</th>
										<th>Remove</th>
                                        
                                    
                                   </tr>
                                </thead>
                                

                                <tbody>
								<?php
								 $query_announcement = mysqli_query($conn,"select * from message
																	LEFT JOIN student ON student.student_id = message.sender_id
																	where  message.reciever_id = '$session_id' order by date_sended DESC
																	")or die(mysqli_error());
								$count_my_message = mysqli_num_rows($query_announcement);	
								if ($count_my_message != '0'){
								 while($row = mysqli_fetch_array($query_announcement)){	
								 $id = $row['message_id'];
								 								 $id_2 = $row['message_id'];
								 $status = $row['message_status'];
								 $sender_id = $row['sender_id'];
								 $sender_name = $row['sender_name'];
								 $reciever_name = $row['reciever_name'];
								 ?>
                            


						
                                        <tr>

                                        <td><?php if ($status == 'read'){
											}else{ ?>
											<input id="" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
											<?php } ?>
											</div>
											<div class="message_content">
											<?php echo $row['content']; ?>
											</div>
											<div class="pull-right">
											
											</td>
                                        <td><strong><?php echo $row['sender_name']; ?></strong></td>
										<td><?php echo $row['date_sended']; ?></td>
										<td><a class="btn btn-outline-primary"  href="#reply<?php echo $id; ?>" data-toggle="modal" ><i class="fas fa-reply"></i> </a>
</td>
<?php include("reply_inbox_message_modal_student.php"); ?>

										<td><a class="btn btn-outline-primary"  href="remove_inbox_message.php?id=<?php echo $id; ?>"  ><i class="fas fa-times"></i></a>

										</td>
                                        </tr>

										<?php }}else{ ?>
								<div class="alert alert-info"><i class="fas fa-times"></i> No Message in Inbox</div>
								<?php } ?>	
                                </tbody>
                            </table>                
                                </div>
                            
                        	</div>
</div>
										</div>
											<hr>
							
								</form>		
                                </div>
								</div>
							

<div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Create Message</h6>
					</div>	
					<?php include('create_message_student.php') ?>
           </div>	
					        </div>
	                        <!-- /block -->
                    </div>
					
					<script src="admin/swal.js"></script>
        
<script type="text/javascript">
	$(document).ready( function() {
		$('.remove').click( function() {
		var id = $(this).attr("id");
			$.ajax({
			type: "POST",
			url: "remove_inbox_message.php",
			data: ({id: id}),
			cache: false,
			success: function(html){
			$("#del"+id).fadeOut('slow', function(){ $(this).remove();}); 
			$('#'+id).modal('hide');
			swal({
  text: "Your Sent message is Successfully Deleted",
  icon :"success"
});
			
			}
			}); 		
			return false;
		});				
	});
</script>



<script>
	jQuery(document).ready(function(){
			jQuery("#reply").submit(function(e){
					e.preventDefault();
					var id = $('.reply').attr("id");
					var _this = $(e.target);
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "reply.php",
						data: formData,
						success: function(html){
							swal({
  text: "Sent message  Successfully",
  icon :"success"
});
						$('#reply'+id).modal('hide');
						}
						
					});
					return false;
				});
			}); 
			</script>

             		<?php include('admin/footer.php'); ?>
		
		<?php include('script.php'); ?>

    </body>
</html>