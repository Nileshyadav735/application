<!--Modal: Login / Register Form-->
<div class="modal fade" id="modalLRFormT" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">

      <!--Modal cascading tabs-->
      <div class="modal-c-tabs text-dark">

        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active btn btn-info" data-toggle="tab" href="#panel71" role="tab"><i class="fas fa-user mr-1"></i>
              Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn btn-info" data-toggle="tab" href="#panel81" role="tab"><i class="fas fa-user-plus mr-1"></i>
              Register</a>
          </li>
        </ul>

        <!-- Tab panels -->
        <div class="tab-content">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel71" role="tabpanel">

            <!--Body-->
            <div class="modal-body mb-1">
			<form id="login_formT" class="form-signin text-dark" method="post">
			<div class="md-form form-sm mb-5">
                <i class="fas fa-user prefix"> <label data-error="wrong" data-success="right" for="modalLRInput10">Your Username</label></i>
				<input type="text" class="form-control form-control-sm validate" id="username modalLRInput10" name="username" placeholder="Username" required>
               
              </div>

			  <div class="md-form form-sm mb-4">
                <i class="fas fa-lock prefix"> <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label></i>		
						<input type="password" class="form-control form-control-sm validate" id="password modalLRInput11" name="password" placeholder="Password" required>
              </div>

			  <div class="text-center mt-2">
                <button title="Click Here to Sign In" id="signin" name="login" class="btn btn-info" type="submit">Log in <i class="fas fa-sign-in-alt ml-1"></i></button>
				<script type="text/javascript">
														$(document).ready(function(){
															$('#signin').tooltip('show');
															$('#signin').tooltip('hide');
														});
														</script>	
			  </div>
						
			  <script type="text/javascript">
														$(document).ready(function(){
															$('#signin_student').tooltip('show'); $('#signin_student').tooltip('hide');
														});
														</script>	
														<script type="text/javascript">
														$(document).ready(function(){
															$('#signin_teacher').tooltip('show'); $('#signin_teacher').tooltip('hide');
														});
														</script>	

														
			</form>
						

<div id="button_form" class="form-signin" >
<div class="modal-footer">
              <div class="options text-center text-md-right mt-1">
                <p>Not a member? <a data-toggle="tab" href="#panel81" role="tab" class="blue-text">Sign Up</a></p>
                <p>Forgot <a href="#" class="blue-text">Password?</a></p>
              </div>
              <button type="button" class="btn btn-danger waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>

	
</div>




             

              
             
            </div>
            <!--Footer-->
           





          </div>
          <!--/.Panel 7-->

          <!--Panel 8-->
          <div class="tab-pane fade" id="panel81" role="tabpanel">

            <!--Body-->
            <div class="modal-body">

			<form id="signin_teacher" class="form-signin text-dark" method="post">
			<div class="md-form form-sm mb-5">
                <i class="fas fa-user prefix"><label data-error="wrong" data-success="right" for="firstname" required>Firstname</label></i>
					<input type="text" class="form-control form-control-sm validate"  name="firstname" placeholder="Firstname" required>
				
					<i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="lastname" required>Lastname</label></i>
					<input type="text" class="form-control form-control-sm validate"  name="lastname"  id="lastname" placeholder="Lastname" required>
				
					<i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="department_id" required><label>Department</label></label></i>
					
					<select name="department_id" class="form-control form-control-sm validate span12">
						<option></option>
						<?php
						$query = mysqli_query($conn,"select * from department order by department_name ")or die(mysqli_error());
						while($row = mysqli_fetch_array($query)){
						?>
						<option value="<?php echo $row['department_id'] ?>"><?php echo $row['department_name']; ?></option>
						<?php
						}
						?>
					</select>
				
					<i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="username" required>Username</label></i>
					<input type="text" class="form-control form-control-sm validate" id="username" name="username" placeholder="Username" required>
				
					<i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="password" required>Password</label></i>
					<input type="password" class="form-control form-control-sm validate" id="password" name="password" placeholder="Password" required>
				
					<i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="cpassword" required>Re-enter Password</label></i>
					<input type="password" class="form-control form-control-sm validate" id="cpassword" name="cpassword" placeholder="Re-type Password" required>
					</div>
			  <div class="text-center form-sm mt-2">
					<button id="signin" name="login" class="btn btn-info" type="submit"><i class="fas fa-sign-in-alt"></i> Sign in</button>
			</div>
			</form>
			

		
			
			

            </div>
            <!--Footer-->
            <div class="modal-footer">
              <div class="options text-right">
                <p class="pt-1">Already have an account? <a  data-toggle="tab" href="#panel71" role="tab" class="blue-text">Log In</a></p>
              </div>
              <button type="button" class="btn btn-outline-info waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!--/.Panel 8-->
        </div>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->

	
			






		
