<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('my_classmates_link.php'); ?>
<?php include('navbar_student.php'); ?>
	 
<div class="container-fluid">

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Announcements</h1>
   		 		</div>
	
<div class="row">
                <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Class Announcements</h6>
				<div class="float-right">
				</div>	
						
			</div>
			<div class="card-body b">
			<?php
								 $query_announcement = mysqli_query($conn,"select * from teacher_class_announcements
																	where  teacher_class_id = '$get_id' order by date DESC
																	")or die(mysqli_error());
								$count = mysqli_num_rows($query_announcement);
								if ($count > 0){
								 while($row = mysqli_fetch_array($query_announcement)){
								 $id = $row['teacher_class_announcements_id'];
								 ?>
										<div class="table-responsive">
  											<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
						
										<thead>
										        <tr>
												<th>Announcement</th>
												<th>Date </th>
												</tr>
												
										</thead>
										<tbody>
								                         
										<tr>
										 <td><strong><i class="fas fa-bullhorn"></i> <?php echo $row['content']; ?></strong></td>
                                         <td><strong><i class="fas fa-calendar"></i> <?php echo $row['date']; ?></strong></td>
                                                                           
								
                                </tr>
                         
					
						   
                              
										</tbody>
									</table>
									<?php }}else{ ?>
								<div class="alert alert-info"><i class="fas fa-info"></i> No Announcements Found.</div>
								<?php } ?>
                                </div>
                               
						 </div>



											
										
											
											</div>
											
							
								
							
                            </div>
                      
				
				<script src="admin/swal.js"></script>


					<script type="text/javascript">
	$(document).ready( function() {

		
		$('.remove').click( function() {
		
		var id = $(this).attr("id");
			$.ajax({
			type: "POST",
			url: "remove_announcements.php",
			data: ({id: id}),
			cache: false,
			success: function(html){
			$("#del"+id).fadeOut('slow', function(){ $(this).remove();}); 
			$('#'+id).modal('hide');
			swal("Your Post is Successfully Deleted"});
		
			}
			}); 
			
			return false;
		});				
	});

</script>
					
                </div>
				
			
            </div>
			
		
		
		
			</div>
</div>        </div>

		<?php include('admin/footer.php'); ?>

		<?php include('script.php'); ?>
    </body>
</html>