<div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Your classes</h6>
				<?php $query = mysqli_query($conn,"select * from teacher_class
										LEFT JOIN class ON class.class_id = teacher_class.class_id
										LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
										where teacher_id = '$session_id' and school_year = '$school_year' ")or die(mysqli_error());
										$count = mysqli_num_rows($query);
										
										
				


										?>
	
											<div class="dropdown no-arrow">
											<a	class="badge badge-info">TOTAL ->  <?php echo $count; ?></a>
									</div>	
			</div>

			
						<ul id="" style="list-style-type: decimal;" class="">
																							
					<?php 	if ($count > 0){
										while($row = mysqli_fetch_array($query)){
										$id = $row['teacher_class_id'];
						?>
												<li id="del<?php echo $id; ?>">


<div class="col mb-4 ">
	<div class="card border-left-primary shadow h-100 py-2">
		<div class="card-body">
			<div class="row no-gutters align-items-center ">
					<div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
					<a href="my_students.php<?php echo '?id='.$id; ?>">
					<p >Class-		<?php echo $row['class_name']; ?></p>
													<p >Subject - <?php echo $row['subject_code']; ?></p>
													
									</a>
					</div>
						
							<div class="col-auto">
				 <a href="my_students.php<?php echo '?id='.$id; ?>" ><i class="fas fa-book fa-5x text-gray-300 fa-fw"></i> </a>
				</div>
			</div>
			<div class="float-right"><a href="#delete<?php echo $id; ?>" data-toggle="modal"><i class="fas fa-trash"></i> Remove</a>
			<?php include("delete_class_modal.php"); ?>

			</div>
		</div>
	</div>
</div>

	   
											<hr>
												
										
										</li>
									<?php } }else{ ?>
									<div class="alert alert-info"><i class="fas fa-info"></i> No Class Currently Added</div>
									<?php  } ?>


									<script type="text/javascript">
									$(document).ready( function() {
										$('.remove').click( function() {
										var id = $(this).attr("id");
											$.ajax({
											type: "POST",
											url: "delete_class.php",
											data: ({id: id}),
											cache: false,
											success: function(html){
											$("#del"+id).fadeOut('slow', function(){ $(this).remove();}); 
											$('#delete'+id).modal('hide');
											$(".modal-backdrop").remove();
											location.reload();
											}
											}); 	
											return false;
										});				
									});
									</script>

									</ul>
									</div>
									</div>


									