<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<?php include('meeting.php'); ?>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="float-right">


            <a href="<?php echo $result->join_url ?>	" class="btn btn-danger"><i class="fas fa-camera"></i>
                Start Meet</a>
            <a href="add_student.php<?php echo '?id='.$get_id; ?>" class="btn btn-info"><i class="fas fa-plus"></i> Add
                Student</a>
            <a onclick="window.open('print_student.php<?php echo '?id='.$get_id; ?>')" class="btn btn-success"><i
                    class="fas fa-list"></i> Student List</a>
        </div>



        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">STUDENTS</h1>

        </div>

        <?php 
$my_student = mysqli_query($conn,"SELECT * FROM teacher_class_student
LEFT JOIN student ON student.student_id = teacher_class_student.student_id 
INNER JOIN class ON class.class_id = student.class_id where teacher_class_id = '$get_id' order by lastname ")or die(mysqli_error());
$count_my_student = mysqli_num_rows($my_student);?>
        <div>
            Number of Students: <span class="badge badge-info"><?php echo $count_my_student; ?></span>




            <?php
														$my_student = mysqli_query($conn,"SELECT * FROM teacher_class_student
														LEFT JOIN student ON student.student_id = teacher_class_student.student_id 
														INNER JOIN class ON class.class_id = student.class_id where teacher_class_id = '$get_id' order by lastname ")or die(mysqli_error());
														while($row = mysqli_fetch_array($my_student)){
														$id = $row['teacher_class_student_id'];
														?>

            <div class="card-body b">
                <input type="text" id="myInput" class="fas fa-search" onkeyup="myFunction()"
                    placeholder=" &#xF002; Search for student.." title="Type in a name">
                <div class="table-responsive">

                    <table cellpadding="0" cellspacing="0" border="0" width="100%" class="table" id="example">

                        <thead>
                            <tr>
                                <th>PROFILE</th>
                                <th>NAME</th>
                                <th>REMOVE</th>



                            </tr>
                        </thead>


                        <tbody>
                            <?php				 
										 	$my_student = mysqli_query($conn,"SELECT *
														FROM teacher_class_student
														LEFT JOIN student ON student.student_id = teacher_class_student.student_id
														INNER JOIN class ON class.class_id = student.class_id where teacher_class_id = '$get_id' order by lastname ")or die(mysqli_error());
	
													while($row = mysqli_fetch_array($my_student)){
														$id = $row['teacher_class_student_id'];
														?>


                            <tr>
                                <td><img id="student_avatar_class" style="border-radius: 50%;" alt="profile"
                                        src="admin/<?php echo $row['location'] ?>" width="100" height="50"
                                        class="img-polaroid">
                                </td>
                                <td><?php echo $row['firstname']." ".$row['lastname'];  ?></td>
                                <td><a href="#reply<?php echo $id; ?>" data-toggle="modal"><i
                                            class="fas fa-times fa-fw icon-large"></i>
                                        <?php include("remove_student_modal.php"); ?>
                                    </a>
                                </td>

                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>


                </div>

            </div>
            <!-- /block -->
            <?php } ?>

            <script type="text/javascript">
            $(document).ready(function() {
                $('.remove').click(function() {
                    var id = $(this).attr("id");
                    $.ajax({
                        type: "POST",
                        url: "remove_student.php",
                        data: ({
                            id: id
                        }),
                        cache: false,
                        success: function(html) {
                            $("#del" + id).fadeOut('slow', function() {
                                $(this).remove();
                            });
                            $('#reply' + id).modal('hide');
                            location.reload();
                        }
                    });
                    return false;
                });
            });
            </script>
        </div>
    </div>


    <?php include('admin/footer.php'); ?>

    <?php include('script.php'); ?>