								    <ul class="nav nav-tabs">
										<li class="btn btn-outline-primary v">
											<a href="student_message.php">For Teacher</a>
										</li>
										<li  class="btn btn-outline-primary v b"><a href="student_message_student.php">For Student</a></li>
									</ul>
								
	<form method="post" class="v" id="send_message">
										<div class="control-group">
											<label>To:Select Teacher</label>
                                          <div class="controls">
                                            <select name="teacher_id" class="chzn-select" required>
                                              	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from teacher order by firstname");
											while($row = mysqli_fetch_array($query)){
											
											?>
											
											<option value="<?php echo $row['teacher_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?> </option>
											
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
								
							
										<div class="control-group">
											<label>Content:</label>
                                          <div class="controls">
											<textarea name="my_message" class="my_message" required></textarea>
                                          </div>
                                        </div>
										<div class="control-group">
                                          <div class="controls">
												<button  class="btn btn-success"><i class="fa fa-paper-plane"></i> Send </button>

                                          </div>
                                        </div>
 </form>
	</div>                            </div>
                        </div>
						

	</div>
</div>

<script src="admin/swal.js"></script>

<script>
			jQuery(document).ready(function(){
			jQuery("#send_message").submit(function(e){
					e.preventDefault();
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "send_message_student.php",
						data: formData,
						success: function(html){
						
						swal("Message Successfully Sended");
						var delay = 2000;
							setTimeout(function(){ window.location = 'student_message.php'  }, delay);  
						
						
						}
						
					});
					return false;
				});
			});
			</script>