<?php include('avatar_modal_student.php'); ?>	
<div id="content-wrapper" class="d-flex flex-column">
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
					<a class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" href="#">Welcome to Class</a>
                    <!-- Topbar date -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <p id="demo"></p>

<script>
var d = new Date();
d = new Date(d).toUTCString();
d= d.split(' ').slice(0, 4).join(' ');
console.log(d);
document.getElementById("demo").innerHTML = d;
</script>
                </form>



                    <ul class="navbar-nav ml-auto">                  

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<?php $query= mysqli_query($conn,"select * from student where student_id = '$session_id'")or die(mysqli_error());
									$row = mysqli_fetch_array($query);
							?>
                                <span class="mr-2  d-lg-inline text-gray-600 small"><?php echo $row['firstname']." ".$row['lastname'];  ?></span>
                                <img class="img-profile rounded-circle"
                                    src="admin/<?php echo $row['location']; ?>">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <div class="dropdown-divider"></div>
								

								<a class="dropdown-item" tabindex="-1" href="change_password_student.php" >
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Change password
                                </a>
								<a class="dropdown-item" tabindex="-1" href="#sampleModal" data-toggle="modal">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
									Change avatar</a>


                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

    
