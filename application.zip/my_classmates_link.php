<div id="wrapper">

<ul class="navbar-nav bg-gradient-primary sidebar toggled sidebar-dark accordion" id="accordionSidebar">

	<!-- Sidebar - Brand -->
	<a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard_student.php">
		<div class="sidebar-brand-icon rotate-n-15">
			<i class="fas fa-laugh-wink"></i>
		</div>
		<div class="sidebar-brand-text mx-3">CAMPUS</div>
	</a>

	<!-- Divider -->
	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link" href="dashboard_student.php">
			<i class="fas fa-angle-left"></i>&nbsp;Back</a>
		</li>
	<hr class="sidebar-divider my-0">

	<!-- Nav Item - Dashboard -->
	<li class="nav-item active">
		<a class="nav-link" href="my_classmates.php<?php echo '?id='.$get_id; ?>">
		<i class="fas fa-user"></i><span>&nbsp;My Classmates</span></a>
	</li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link" href="progress.php<?php echo '?id='.$get_id; ?>">
		<i class="fas fa-tasks"></i><span>&nbsp;My Progress</pan></a>
	</li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="subject_overview_student.php<?php echo '?id='.$get_id; ?>">
		<i class="fas fa-info"></i><span>&nbsp;Subject Overview</span></a></li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="downloadable_student.php<?php echo '?id='.$get_id; ?>"><i class="fas fa-book"></i><span>&nbsp;Materials</span></a>
	</li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="assignment_student.php<?php echo '?id='.$get_id; ?>"><i class="fas fa-clipboard-list"></i><span>&nbsp;Assignments</span></a></li>
	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="announcements_student.php<?php echo '?id='.$get_id; ?>"><i class="fas fa-bullhorn"></i><span>&nbsp;Announcements</span></a></li>
	<hr class="sidebar-divider my-0">

	

	



	<!-- Divider -->
	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link" href="student_quiz_list.php<?php echo '?id='.$get_id; ?>">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>&nbsp;Quiz</span></a>
	</li>
	<!-- Divider -->
	<hr class="sidebar-divider  d-none d-md-block">

	<!-- Sidebar Toggler (Sidebar) -->
	<div class="text-center d-none d-md-inline">
		<button class="rounded-circle border-0" id="sidebarToggle"></button>
	</div>

   

</ul>