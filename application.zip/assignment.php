<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Assignments</h1>
   		 		</div>
	<div class="row">
	<div class="col-xl col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Assigned Assignments</h6>
				<div class="float-right">
				<button class="open-button btn btn-info v" onclick="openForma(); myFunctiona()"><i class="fas fa-plus"></i>Add Assignment</button>
</div>
									</div>
									<input type="text" id="myInput" class="fas fa-search" onkeyup="myFunction()" placeholder=" &#xF002; Search for assignment.." title="Type in a name">

									<div class="card-body table-responsove b">
  									<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
										<thead>
										        <tr>
												<th>Date Upload</th>
												<th>Assignment Name</th>
												<th>Description</th>
												<th></th>
												<th></th>
												</tr>
										</thead>
										<tbody>
											
                              		<?php
										$query = mysqli_query($conn,"select * FROM assignment where class_id = '$get_id' and teacher_id = '$session_id' order by fdatein DESC ")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
										$id  = $row['assignment_id'];
										$floc  = $row['floc'];
									?>                              
								<tr>
										 <td><?php echo $row['fdatein']; ?></td>
                                         <td><?php  echo $row['fname']; ?></td>
                                         <td><?php echo $row['fdesc']; ?></td>                                      
                                         <td width="">
										  <form method="post" action="view_submit_assignment.php<?php echo '?id='.$get_id ?>&<?php echo 'post_id='.$id ?>">
										
										 <button  title="View Student who submit Assignment" id="<?php echo $id; ?>view" class="btn btn-success"><i class="fas fa-folder-open">Submissions</i></button>
										 </td>  
										 <td>
										</form>
										<?php 
										if ($floc == ""){
										}else{
										?>
										 <a data-placement="bottom" title="Download" id="<?php echo $id; ?>download"  class="btn btn-info" href="<?php echo $row['floc']; ?>"><i class="fas fa-download "></i></a>
										<?php } ?>
										
										 <a data-placement="bottom" title="Remove" id="<?php echo $id; ?>remove"  class="btn btn-danger"  href="#del<?php echo $id; ?>" data-toggle="modal"><i class="fas fa-times"></i></a>
										 <?php include('delete_assigment_modal.php'); ?>	
																		
									</td>                                      
														<script type="text/javascript">
														$(document).ready(function(){
															$('#<?php echo $id; ?>download').tooltip('show');
															$('#<?php echo $id; ?>download').tooltip('hide');
														});
														</script>
														<script type="text/javascript">
														$(document).ready(function(){
															$('#<?php echo $id; ?>remove').tooltip('show');
															$('#<?php echo $id; ?>remove').tooltip('hide');
														});
														</script>
														<script type="text/javascript">
														$(document).ready(function(){
															$('#<?php echo $id; ?>view').tooltip('show');
															$('#<?php echo $id; ?>view').tooltip('hide');
														});
														</script>
                                </tr>
						 <?php } ?>
										</tbody>
									</table>
									<script>
function myFunctiona() {
  var elmnt = document.getElementById("myForma");
  elmnt.scrollIntoView();
}
</script>	
	
                                </div>
								<?php include('assignment_sidebar.php') ?>

			
				</div>
            </div>
                    </div>
            </div>

		<?php include('admin/footer.php'); ?>
		</div>
		
<?php include('script.php'); ?>
		