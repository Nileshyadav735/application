<!--Modal: Login / Register Form-->
<div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">

      <!--Modal cascading tabs-->
      <div class="modal-c-tabs text-dark">

        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active btn btn-info" data-toggle="tab" href="#panel7" role="tab"><i class="fas fa-user mr-1"></i>
              Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link btn btn-info" data-toggle="tab" href="#panel8" role="tab"><i class="fas fa-user-plus mr-1"></i>
              Register</a>
          </li>
        </ul>

        <!-- Tab panels -->
        <div class="tab-content">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel7" role="tabpanel">

            <!--Body-->
            <div class="modal-body mb-1">
			<form id="login_form1" class="form-signin" method="post">
			<div class="md-form form-sm mb-5">
                <i class="fas fa-user prefix"> <label data-error="wrong" data-success="right" for="modalLRInput10">Your Username</label></i>
				<input type="text" class="form-control form-control-sm validate" id="username modalLRInput10" name="username" placeholder="Username" required>
               
              </div>

			  <div class="md-form form-sm mb-4">
                <i class="fas fa-lock prefix"> <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label></i>		
						<input type="password" class="form-control form-control-sm validate" id="password modalLRInput11" name="password" placeholder="Password" required>

			  <div class="text-center  mt-2">
                <button title="Click Here to Sign In" id="signin" name="login" class="btn btn-info" type="submit">Log in <i class="fas fa-sign-in ml-1"></i></button>
			
			  </div>
        </div>
			
			</form>
						

<div id="button_form" class="form-signin" >
<div class="modal-footer">
              <div class="options text-center text-md-right mt-1">
                <p>Not a member? <a data-toggle="tab" href="#panel8" role="tab" class="blue-text">Sign Up</a></p>
                <p>Forgot <a href="#" class="blue-text">Password?</a></p>
              </div>
              <button type="button" class="btn btn-danger waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>

	
</div>




             

              
             
            </div>
            <!--Footer-->
           





          </div>
          <!--/.Panel 7-->

          <!--Panel 8-->
          <div class="tab-pane fade" id="panel8" role="tabpanel">

            <!--Body-->
            <div class="modal-body">

			<form id="signin_student" class="form-signin" method="post">
			 <div class="md-form form-sm mb-5">
                <i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="modalLRInput12" required>Username</label></i>
					<input type="text" class="form-control form-control-sm validate" id="username" name="username" placeholder="ID Number" required>
			
                <i class="fas fa-envelope prefix"><label data-error="wrong" data-success="right" for="modalLRInput12" required>Your email</label></i> 
				               <input type="email" id="modalLRInput12 email" name="email" class="form-control form-control-sm validate">
             
                <i class="fas fa-user prefix"><label data-error="wrong" data-success="right" for="modalLRInput12" required>First Name</label></i>
				<input type="text" class="form-control form-control-sm validate" id="firstname" name="firstname" placeholder="Firstname" required>

                <i class="fas fa-user prefix"><label data-error="wrong" data-success="right" for="modalLRInput12" required>Last Name</label></i>
<input type="text" class="form-control form-control-sm validate" id="lastname" name="lastname" placeholder="Lastname" required>

			<label><i class="fas fa-backpack prefix"><Strong>Class</strong></label></i> 
			<select name="class_id" class="form-control form-control-sm validate span5">
				<option></option>
				<?php
				$query = mysqli_query($conn,"select * from class order by class_name ")or die(mysqli_error());
				while($row = mysqli_fetch_array($query)){
				?>
				<option value="<?php  echo $row['class_id']; ?>"><?php echo $row['class_name']; ?></option>
				<?php
				}
				?>
			</select>
             <i class="fas fa-lock prefix"><label data-error="wrong" data-success="right" for="modalLRInput13 password"  name="password" placeholder="Password" required>Your password</label></i> 
			  <input type="password" id="modalLRInput13 password" name="password" class="form-control form-control-sm validate">
             
                <i class="fas fa-lock prefix"><label data-error="wrong" data-success="right" for="modalLRInput14 cpassword">Repeat password</label></i>
                <input type="password" id="modalLRInput14 cpassword" name="cpassword" placeholder="Re-type Password" required class="form-control form-control-sm validate">
              </div>
			  <div class="text-center form-sm mt-2">
			<button id="signin" name="login" class="btn btn-info" type="submit"><i class="fas fa-sign-in ml-1"></i> Sign in</button>
			</div>

			 

			</form>
			
		
			
			

            </div>
            <!--Footer-->
            <div class="modal-footer">
              <div class="options text-right">
                <p class="pt-1">Already have an account? <a  data-toggle="tab" href="#panel7" role="tab" class="blue-text">Log In</a></p>
              </div>
              <button type="button" class="btn btn-outline-info waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!--/.Panel 8-->
        </div>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->

	
			
