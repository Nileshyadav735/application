<?php include('dbcon.php'); ?>
<?php include('count.php'); ?>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <ul class="navbar-nav bg-gradient-primary sidebar toggled sidebar-dark accordion" id="accordionSidebar">
    
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard_student.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">CAMPUS</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="dashboard_student.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>&nbsp;My Class</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

			<li class="nav-item active">
                <a class="nav-link" href="student_notification.php">
                    <i class="fas fa-bell"></i>
                    <span>&nbsp;Notification
				<?php if($not_read == '0'){
				}else{ ?>
					<span class="badge badge-important"><?php echo $not_read; ?></span>
				<?php } ?></span></a>
            </li>


			<li class="nav-item active">
			<?php
			$message_query = mysqli_query($conn,"select * from message where reciever_id = '$session_id' and message_status != 'read' ")or die(mysqli_error());
			$count_message = mysqli_num_rows($message_query);
			?>
                <a class="nav-link" href="student_message.php">
                    <i class="fas fa-envelope"></i>
                    <span>&nbsp;Message
				<?php if($count_message == '0'){
				}else{ ?>
					<span class="badge badge-important"><?php echo $count_message; ?></span>
				<?php } ?></span></a>
            </li>

			<li class="nav-item active">
                <a class="nav-link" href="backpack.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>&nbsp;Backpack</span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

           

        </ul>
        <!-- End of Sidebar -->
