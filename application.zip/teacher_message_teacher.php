<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('teacher_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
				
				<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">MESSAGES</h1>
   		 		</div>
	<div class="row">

                <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Your Message</h6>
					</div>		
										<ul class="nav nav-pills ">
										<li class="btn btn-outline-primary v"><a href="teacher_message.php"><i class="fas fa-envelope fa-fw"></i>inbox</a></li>
										<li class="v"><a href="sent_message.php"><i class="fas fa-envelope fa-fw"></i>Sent messages</a></li>
										</ul>
										<hr>

										
										<div class="card-body b">
                        <!-- block -->
                        <div class="table-responsive">

						
										
													
											
							
						<div class="post"  id="<?php echo $id; ?>">
            <table cellpadding="0" cellspacing="0" border="0" width="100%"  class="table table-bordered" id="example dataTable" >
								
                                <thead>
                                  <tr>
                                  <th>Message</th>
                                        <th>From</th>
                                        <th><i class="fas fa-clock"></i>Time</th>
                                        <th>Reply</th>
										<th>Remove</th>
                                        
                                    
                                   </tr>
                                </thead>
                                

                                <tbody>
								<?php
								 $query_announcement = mysqli_query($conn,"select * from message
																	LEFT JOIN teacher ON teacher.teacher_id = message.sender_id
																	where  message.reciever_id = '$session_id' order by date_sended DESC
																	")or die(mysqli_error());
								$count_my_message = mysqli_num_rows($query_announcement);	
								if ($count_my_message != '0'){
								 while($row = mysqli_fetch_array($query_announcement)){
								 $id = $row['message_id'];
								 $sender_id = $row['sender_id'];
								 $sender_name = $row['sender_name'];
								 $reciever_name = $row['reciever_name'];
								 ?>
                            


						
                                        <tr>

                                        <td>
											</div>
											<div class="message_content">
											<?php echo $row['content']; ?>
											</div>
											<div class="float-right">
											
											</td>
                                        <td><strong><?php echo $row['sender_name']; ?></strong></td>
										<td><?php echo $row['date_sended']; ?></td>
										<td><a class="btn btn-outline-primary"  href="#rep<?php echo $id; ?>" data-toggle="modal" ><i class="fas fa-reply"></i> </a>
</td>
<?php include("reply_inbox_message_modal.php"); ?>

										<td><a class="btn btn-outline-primary"   href="remove_inbox_message_teacher.php?id=<?php echo $id; ?>"  ><i class="fas fa-times"></i></a>
											
													
										</td>
                                        </tr>

										<?php }}else{ ?>
								<div class="alert alert-info"><i class="fas fa-times"></i> No Message in Inbox</div>
								<?php } ?>	
                                </tbody>
                            </table>                
							</div>
                            
                        	</div>


									
										
											
											
											 
															
													
													</div>
										</div>
											<hr>
							
									
								</div>
								<div  class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Create Message</h6>
					</div>	
					<?php include('create_message_teacher.php') ?>
           </div>	
					        </div>
	                        <!-- /block -->
                    </div>
				
     
			<?php include('admin/footer.php'); ?>
<?php include('script.php'); ?>
<script src="admin/swal.js"></script>

<script>
			jQuery(document).ready(function(){
			jQuery("#reply").submit(function(e){
					e.preventDefault();
					var id = $('.rep').attr("id");
					var _this = $(e.target);
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "reply.php",
						data: formData,
						success: function(html){
						swal({title:"Replied" ,text:"replied successfully", icon:"success"});
						setTimeout(() => {location.reload();
						}, 1500);
						$('#rep'+id).modal('hide');
						}
						
					});
					return false;
				});
			});
			</script>
