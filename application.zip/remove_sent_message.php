<?php include('admin/dbcon.php'); 

$id = $_GET['id'];
$del = mysqli_query($conn,"delete from message_sent where message_sent_id = '$id'")or die(mysqli_error());


if($del)
{
    header("location:sent_message_student.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>

