<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php $get_id = $_GET['id']; ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>

<?php 
	  $post_id = $_GET['post_id'];
	  if($post_id == ''){
	  ?>
		<script>
		window.location = "assignment_student.php<?php echo '?id='.$get_id; ?>";
		</script>
	  <?php
	  }
	
 ?>
 
 <div class="container-fluid" id="studentTableDiv">

 <div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Assignment</h1>
</div>
<div class="row">
<div class="col-xl-8 col-lg-7">
				<div class="card shadow mb-4">
		<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">
									<?php
										$query1 = mysqli_query($conn,"select * FROM assignment where assignment_id = '$post_id'")or die(mysqli_error());
										$row1 = mysqli_fetch_array($query1);
									
									?>
									<div class="alert alert-info">Submitted Assignment In : <?php echo $row1['fname']; ?>
									
									<div id=""></h6>
				<div class="float-right">
				<a href="assignment.php<?php echo '?id='.$get_id; ?>" class="btn btn-info"><i class="fas fa-arrow-left"></i> Back</a></div>
                            
								</div>
                            </div>
							<div class="table-responsive">	
							<div class="card-body b v">

							<table cellpadding="0" cellspacing="0" border="0" class="table" id="">
						
						<thead>
								<tr>
								<th>Date Upload</th>
								<th>File Name</th>
								<th>Description</th>
								<th>Submitted by:</th>
								<th></th>
								<th>Grade</th>
								</tr>
								
						</thead>
						<tbody>
							
					  <?php
						$query = mysqli_query($conn,"select * FROM student_assignment 
						LEFT JOIN student on student.student_id  = student_assignment.student_id
						where assignment_id = '$post_id'  order by assignment_fdatein DESC")or die(mysqli_error());
						while($row = mysqli_fetch_array($query)){
						$id  = $row['student_assignment_id'];
					?>                              
						<tr>
						 <td><?php echo $row['assignment_fdatein']; ?></td>
						 <td><?php  echo $row['fname']; ?></td>
						 <td><?php echo $row['fdesc']; ?></td>                                                                        
						 <td><?php echo $row['firstname']." ".$row['lastname']; ?></td>                                                                        
						 <td><a href="<?php echo $row['floc']; ?>"><i class="fas fa-download icon-large"></i></a></td>                                                                        
						 <td width="140">
						 <form method="post" action="save_grade.php">
						 <input type="hidden" class="span4" name="id" value="<?php echo $id; ?>">
						 <input type="hidden" class="span4" name="post_id" value="<?php echo $post_id; ?>">
						 <input type="hidden" class="span4" name="get_id" value="<?php echo $get_id; ?>">
						 <input type="text" class="span4" name="grade" value="<?php echo $row['grade']; ?>">
						 <button name="save" class="btn btn-success" id="btn_s"><i class="fas fa-save"></i> Save</button>
						 </form>
						 </td>                                                                        
				</tr>
		 
		 <?php } ?>
	
			  
						</tbody>
					</table>
</div>

</div>
							</div>
							</div>

                             
							<?php include('admin/footer.php'); ?>

<?php include('script.php'); ?>
					
												
				