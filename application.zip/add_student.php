<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<?php $get_id = $_GET['id']; ?>
<div class="container-fluid" >
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">ADD STUDENTS</h1>
	
</div>
<div class="col-xl-8 col-lg-8">
        <div class="card shadow mb-4">
								
								<form method="post" action="">

							
										<button name="submit" type="submit" class="btn btn-info float-right "><i class="fas fa-plus"></i>&nbsp;Add Student</button>
	<a href="my_students.php<?php echo '?id='.$get_id; ?>" class="btn btn-info float-right v"><i class="fas fa-left"></i> Back</a>
												<br>
												<br>
												<div class="table-responsive" >
												<div class="card-body b" >
												<input type="text" id="myInput" class="fas fa-search" onkeyup="myFunction()" placeholder=" &#xF002; Search for student.." title="Type in a name">


							 <table cellpadding="0" cellspacing="0" border="0"  width="100%"  class="table" id="example">
                          
						 <thead>
		
                                <tr>
                               
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Course Section</th>
                  
                                    <th><i class="fas fa-plus fa-fw "></i></th>
                                </tr>
                            </thead>
                            <tbody>
					
                                         <?php
							
							
										$a = 0 ;
										$query = mysqli_query($conn,"select * from student LEFT JOIN class on class.class_id = student.class_id
												
										") or die(mysqli_error());
										while ($row = mysqli_fetch_array($query)) {
                                        $id = $row['student_id'];
										$a++;
									
                                        ?>
								
										<tr>
										
                                        <td width="70"><img  class="img-rounded" style="border-radius: 50%;" src="admin/<?php echo $row['location']; ?>" height="50" width="80"></td>
                                        <td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td> 
										<td><?php echo $row['class_name']; ?></td> 
								
										<td width="10">
										<input 	id="optionsCheckbox" type="checkbox"  value="Add" name="add_student<?php echo $a; ?>" >
									
										</select>
										<input type="hidden" name="test" value="<?php echo $a; ?>">
										<input type="hidden" name="student_id<?php echo $a; ?>" value="<?php echo $id; ?>">
										<input type="hidden" name="class_id<?php echo $a; ?>" value="<?php echo $get_id; ?>">
										<input type="hidden" name="teacher_id<?php echo $a; ?>" value="<?php echo $session_id; ?>">
										</td>
									
                                   <?php } ?>    
										
                                </tr>
                         
                            </tbody>
                        </table>
					
						</form>
						</div>
                            </div>
						
  			
							
	<?php

if (isset($_POST['submit'])){

	$test = $_POST['test'];
	for($b = 1; $b <=  $test; $b++)
	{
	

		
		
	$test1 = "student_id".$b;
	$test2 = "class_id".$b;
	$test3 = "teacher_id".$b;
	$test4 = "add_student".$b;
	
	$id = $_POST[$test1];
	$class_id = $_POST[$test2];
	$teacher_id = $_POST[$test3];
	$Add = $_POST[$test4];
	
 	$query = mysqli_query($conn,"select * from teacher_class_student where student_id = '$id' and teacher_class_id = '$class_id' ")or die(mysqli_error());
	$count = mysqli_num_rows($query); 
	
 	if ($count > 0){ ?>
	 <script src="admin/swal.js">
	 </script>
	<script>
		 swal({
  title: "",
  text: "Student Already in class",
  icon: "error",
  button: "Close",
}); 
	setTimeout(() => { window.location = "my_students.php<?php echo '?id='.$get_id; ?>"; 
},2000);
	</script>		
	<?php
	}else  
	if($Add == 'Add'){
		mysqli_query($conn,"insert into teacher_class_student (student_id,teacher_class_id,teacher_id) values('$id','$class_id','$teacher_id') ")or die(mysqli_error());
}else{
	
	
	
	}
	

	
?>
	
	<?php
	}
	
	
	
	}
	 
	
	?>
	
					
						
            
                             
                      </div>  
					  </div>
               
		<?php include('admin/footer.php'); ?>
        
		<?php include('script.php'); ?>
  