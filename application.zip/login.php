<?php
		include('admin/dbcon.php');
		session_start();
		$username = $_POST['username'];
		$password = $_POST['password'];
		/* student */
			$query = "SELECT * FROM student WHERE username='$username' AND password='$password'";
			$result = mysqli_query($conn,$query)or die(mysqli_error());
			$row = mysqli_fetch_array($result);
			$num_row = mysqli_num_rows($result);
		/* teacher */
		$query_teacher = mysqli_query($conn,"SELECT * FROM teacher WHERE username='$username' AND password='$password' AND status='1'")or die(mysqli_error());
		$num_row_teacher = mysqli_num_rows($query_teacher);
		$row_teahcer = mysqli_fetch_array($query_teacher);
		if( $num_row > 0 ) { 
		$_SESSION['id']=$row['student_id'];
		echo 'true_student';
		mysqli_query($conn,"insert into user_log (username,login_date,user_id)values('$username',NOW(),".$row['student_id'].")")or die(mysqli_error());
		session_regenerate_id(false);
		}else if ($num_row_teacher > 0){
		$_SESSION['id']=$row_teahcer['teacher_id'];
		mysqli_query($conn,"insert into user_log (username,login_date,user_id)values('$username',NOW(),".$row_teahcer['teacher_id'].")")or die(mysqli_error());

		echo 'true';
		session_regenerate_id(false);
		 }else{ 
				echo 'false';
		}	
				
		?>