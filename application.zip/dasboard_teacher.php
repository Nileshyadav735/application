<?php include('header_dashboard.php'); ?>    
<?php include('session.php'); ?>
<?php include('teacher_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid" >
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">CLASS</h1>  
</div>
<div class="row">
<?php include('teacher_class.php'); ?>
<?php include('teacher_right_sidebar.php') ?>    
<?php include("search_other_class.php"); ?>
</div>
<?php include('admin/footer.php'); ?>
<?php include('script.php'); ?>
`
    