<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('teacher_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
				
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">BACKPACK</h1>
   		 		</div>
	<div class="row">
	<div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Your Backpack</h6>
				<div class="float-right">
												Check All <input type="checkbox"  name="selectAll" id="checkAll" />
												<script>
												$("#checkAll").click(function () {
													$('input:checkbox').not(this).prop('checked', this.checked);
												});
												</script>					
									</div>
									</div>		
                     			<?php
								$query_backpack = mysqli_query($conn,"select * FROM teacher_backpack where teacher_id = '$session_id'  order by fdatein DESC ")or die(mysqli_error());
								$num_row = mysqli_num_rows($query_backpack);
								if ($num_row > 0){
								?>
									
									<form action="delete_backpack_teacher.php" method="post">
  									<table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
									<a data-toggle="modal" href="#backup_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash"></i></a>
									<?php include('modal_backpack_delete.php'); ?>
										<thead>
										        <tr>
												<th></th>
												<th>Date Upload</th>
												<th>File Name</th>
												<th>Description</th>
												<th>Download</th>
												</tr>
										</thead>
										<tbody>
                              		<?php
										$query = mysqli_query($conn,"select * FROM teacher_backpack where teacher_id = '$session_id'  order by fdatein DESC")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
										$id  = $row['file_id'];
									?>                              
										<tr id="del<?php echo $id; ?>">
										<td width="30">
											<input id="" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
										</td>
										 <td><?php echo $row['fdatein']; ?></td>
                                         <td><?php  echo $row['fname']; ?></td>
                                         <td><?php echo $row['fdesc']; ?></td>                                      
                                         <td width="30"><a href="<?php echo $row['floc']; ?>"><i class="fas fa-download icon-large"></i></a></td>                                      
										</tr>
									<?php } ?>
										</tbody>
									</table>
									</form>
									<?php }else{ ?>
									<div class="alert alert-info v"><i class="fas fa-info"></i> No Files Inside Your Backpack.</div>
									<?php } ?>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
			<?php include('admin/footer.php'); ?>
        </div>

		<?php include('script.php'); ?>
    </body>
</html>