<div id="wrapper">

<ul class="navbar-nav bg-gradient-primary sidebar toggled sidebar-dark accordion" id="accordionSidebar">

	<!-- Sidebar - Brand -->
	<a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
		<div class="sidebar-brand-icon rotate-n-15">
			<i class="fas fa-laugh-wink"></i>
		</div>
		<div class="sidebar-brand-text mx-3">CAMPUS</div>
	</a>

	<!-- Divider -->
	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link" href="dasboard_teacher.php">
			<i class="fas fa-angle-left"></i>&nbsp;Back</a>
		</li>
	<hr class="sidebar-divider my-0">

	<!-- Nav Item - Dashboard -->
	<li class="nav-item active">
		<a class="nav-link" href="my_students.php<?php echo '?id='.$get_id; ?>">
		<i class="fas fa-user"></i><span>&nbsp;My Students</span></a>
	</li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link" href="subject_overview.php<?php echo '?id='.$get_id; ?>">
		<i class="fas fa-tasks"></i><span>&nbsp;subject overview</pan></a>
	</li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="downloadable.php<?php echo '?id='.$get_id; ?>">
		<i class="fas fa-info"></i><span>&nbsp;downloadable</span></a></li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="assignment.php<?php echo '?id='.$get_id; ?>"><i class="fas fa-book"></i><span>&nbsp;assignment</span></a>
	</li>

	<hr class="sidebar-divider my-0">

	<li class="nav-item active">
		<a class="nav-link"  href="announcements.php<?php echo '?id='.$get_id; ?>"><i class="fas fa-clipboard-list"></i><span>&nbsp;announcements</span></a></li>
	<hr class="sidebar-divider my-0">


	<li class="nav-item active"><a class="nav-link"  class="nav-link"  href="class_quiz.php<?php echo '?id='.$get_id; ?>">
<i class="fas fa-calendar"></i><span>&nbsp;class_quiz </span></a></li>
	
	<hr class="sidebar-divider  d-none d-md-block">

	<!-- Sidebar Toggler (Sidebar) -->
	<div class="text-center d-none d-md-inline">
		<button class="rounded-circle border-0" id="sidebarToggle"></button>
	</div>

   

</ul>