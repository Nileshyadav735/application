<style>
.form-popup {
  display: none;
  bottom: 0;
  right: 15px;
   z-index: 9;
}
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
<script>
function openFormcl() {
  document.getElementById("myFormcl").style.display = "block";
}

function closeFormcl() {
  document.getElementById("myFormcl").style.display = "none";
}
</script>
</div>
<div class="form-popup" id="myFormcl">

<div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Add Quiz To Class</h6>
				</div>
   <form class="form-horizontal" method="post">
										<div class="form-group position-relative v">
											<label class="control-label" for="inputEmail">Quiz</label>
											<div class="controls">
											<select name="quiz_id">
											<option></option>
												<?php  $query = mysqli_query($conn,"select * from quiz where teacher_id = '$session_id'")or die(mysqli_error());
												while ($row = mysqli_fetch_array($query)){ $id = $row['quiz_id']; ?>
												<option value="<?php echo $id; ?>"><?php echo $row['quiz_title']; ?></option>
												<?php } ?>
											</select>
											</div>
										</div>
										<div class="form-group position- v">
											<label class="control-label" for="inputPassword">Test Time (in minutes)</label>
											<div class="controls">
											<input type="text" class="span3" name="time" id="inputPassword time" placeholder="Test Time" required>
											</div>
										</div>
										<div class="table-responsive">

												<table class="table" id="question">
                <th></th>
                <th>Class</th>
                <th>Subject</th>
                <th></th>
				
				<tbody>
					<?php $query = mysqli_query($conn,"select * from teacher_class
										LEFT JOIN class ON class.class_id = teacher_class.class_id
										LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
										where teacher_id = '$session_id' and school_year = '$school_year' ")or die(mysqli_error());
										$count = mysqli_num_rows($query);
										

										while($row = mysqli_fetch_array($query)){
										$id = $row['teacher_class_id'];
				
										?>
					<tr>
					<td width="30">
						<input id="optionsCheckbox"  name="selector[]" type="checkbox" value="<?php echo $id; ?>">
					</td>
					<td><?php echo $row['class_name']; ?></td>
					<td><?php echo $row['subject_code']; ?></td>
					</tr>
					<?php } ?>
				</tbody>
				</table>
		
											
										<div class="form-group position-relative v">
										<div class="controls">
										
										<button name="save" type="submit" class="btn btn-info"><i class="fas fa-save"></i> Save</button>
										<button type="button" class="btn btn-danger" onclick="closeFormcl()"><i class="fas fa-times"></i>Close</button>
										</div>
										</div>
										</form>
										
									</div>
										
									</div>
										<?php
										if (isset($_POST['save'])){
											$quiz_id = $_POST['quiz_id'];
											$time = $_POST['time'] * 60;
											$id=$_POST['selector'];
											
													$name_notification  = 'Added Quiz In';
													
											$N = count($id);
											for($i=0; $i < $N; $i++)
											{
												mysqli_query($conn,"insert into class_quiz (teacher_class_id,quiz_time,quiz_id) values('$id[$i]','$time','$quiz_id')")or die(mysqli_error());
												mysqli_query($conn,"insert into notification (teacher_class_id,notification,date_of_notification,link) value('$id[$i]','$name_notification',NOW(),'student_quiz_list.php')")or die(mysqli_error());
											} ?>
											<script>
												window.location = 'teacher_quiz.php';
											</script>
											<?php
										}
										?>
