<style>
.form-popup {
  display: none;
  bottom: 0;
  right: 15px;
   z-index: 9;
}
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
<script>
function openFormd() {
  document.getElementById("myFormd").style.display = "block";
}
function closeFormd() {
  document.getElementById("myFormd").style.display = "none";
}

</script>
</div>
<div class="form-popup v" id="myFormd">


<div class="col-xl-3 col-lg-8">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-body">

            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Search Past Year</h6>
								</div>	
			</div>

<center>
      
      <form method="post" action="search_class.php">	
										<div class="form-group position-relative">
											<label>School Year:</label>
                                          <div class="controls">
                                            <select name="school_year"  class="span8" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from school_year order by school_year DESC");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option><?php echo $row['school_year']; ?></option>
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
											<div class="form-group position-relative">
                                          <div class="controls">
												<button name="search" class="btn btn-info"><i class="fas fa-search"></i> Search</button>
                        <button type="button" class="btn btn-danger" onclick="closeFormd()"><i class="fas fa-times"></i>Close</button>
                        
                                          </div>
                                        </div>
                                </form>

                                </center>
                                </div>
                                        </div>