
								<ul class="nav nav-tabs">
										<li class="btn btn-outline-primary v">
											<a href="teacher_message.php">For Teacher</a>
										</li>
										<li  class="btn btn-outline-primary v b"><a href="teacher_message_teacher.php">For Student</a></li>
									</ul>
								
		
								<form method="post" class="v"  id="send_message_student">
									<div class="control-group">
											<label>To: Student</label>
                                          <div class="controls">
                                            <select name="student_id"  class="chzn-select" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from teacher_class_student
																  LEFT JOIN student ON student.student_id = teacher_class_student.student_id
											 group by teacher_class_student.student_id order by firstname ASC");
											while($row = mysqli_fetch_array($query)){
											
											?>
											<option value="<?php echo $row['student_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?> </option>
											<?php } ?>
                                            </select>
                                          </div>
                                        </div>
										
										<div class="control-group">
											<label>Content:</label>
                                          <div class="controls">
											<textarea name="my_message" class="my_message" required></textarea>
                                          </div>
                                        </div>
										<div class="control-group">
                                          <div class="controls">
												<button  class="btn btn-info"><i class="fas fa-reply"></i> Send </button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
						

	</div>
</div>									<script src="admin/swal.js"></script>

<script>
			jQuery(document).ready(function(){
			jQuery("#send_message_student").submit(function(e){
					e.preventDefault();
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "send_message_teacher_to_student.php",
						data: formData,
						success: function(html){
						swal({title:"SENT" ,text:"Message Successfully Sended", icon:"success"});
						var delay = 2000;
							setTimeout(function(){ location.reload();  }, delay);  
						
						
						}
						
					});
					return false;
				});
			});
			</script>