<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('teacher_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
	
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">QUIZ</h1>
   		 		</div>
					
	<div class="row">

                <div class="col-xl col-lg-7">
		
<div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Add Quiz</h6>
				<div class="float-right">



							
    <button class="open-button btn btn-info v" onclick="openForm(); myFunction()"><i class="fas fa-plus"></i> Add Quiz</button>
	<button class="open-button btn btn-info v" onclick="openFormcl(); myFunctioncl()"><i class="fas fa-plus"></i>Add Quiz to Class</button>

			
									</div>
					</div>	
								<div class="table-responsive">
									<form action="delete_quiz.php" method="post">
  									<table cellpadding="0" cellspacing="0" border="0" class="table" id="">
									<a data-toggle="modal" href="#backup_delete" id="delete"  class="btn btn-danger v" name=""><i class="fas fa-trash "></i></a>
									<?php include('modal_delete_quiz.php'); ?>
										<thead>
										        <tr>
												<th></th>
												<th>Quiz title</th>
												<th>Description</th>
												<th>Date Added</th>
												<th>Questions</th>
												<th></th>
												</tr>
										</thead>
										<tbody>
                              		<?php
										$query = mysqli_query($conn,"select * FROM quiz where teacher_id = '$session_id'  order by date_added DESC ")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
										$id  = $row['quiz_id'];
									?>                              
										<tr id="del<?php echo $id; ?>">
										<td width="30">
											<input id="optionsCheckbox" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
										</td>
										 <td><?php echo $row['quiz_title']; ?></td>
                                         <td><?php  echo $row['quiz_description']; ?></td>
                                         <td><?php echo $row['date_added']; ?></td>                                      
                                         <td><a href="quiz_question.php<?php echo '?id='.$id; ?>">Questions</a></td>                                      
                                         <td width="30"><a href="edit_quiz.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="fas fa-pen"></i></a></td>                                                                         
										</tr>
									<?php } ?>
										</tbody>
									</table>
									</div>
									</form>
									
									<?php include('add_quiz.php'); ?>
									
									<?php include('add_quiz_to_class.php'); ?>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('admin/footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
	
		<script>
function myFunction() {
  var elmnt = document.getElementById("myForm");
  elmnt.scrollIntoView();
}

function myFunctioncl() {
  var elmnt = document.getElementById("myFormcl");
  elmnt.scrollIntoView();
}
</script>