<div id="reply<?php echo $id; ?>" class="fade modal" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Reply</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <center>

<div class="control-group">
	<label class="control-label" for="inputEmail">To:</label>
	<div class="controls">
		<input type="hidden" name="sender_id" id="inputEmail" value="<?php echo $sender_id; ?>" readonly>
		<input type="hidden" name="my_name" value="<?php echo $reciever_name; ?>" readonly>
		<input type="text" name="name_of_sender"  id="inputEmail" value="<?php echo $sender_name; ?>" readonly>
	</div>
</div>
<div class="control-group">
	<label class="control-label" for="inputPassword">Content:</label>
	<div class="controls">
		<textarea name="my_message"></textarea>
	</div>
</div>
<div class="control-group">
	<div class="controls">
	<button type="submit" name="reply" id="<?php echo $id; ?>" class="btn btn-success reply"><i class="fas fa-reply"></i> Reply</button>
	</div>
</div>

</center>		
					
      </div>
      <div class="modal-footer">
	  <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times"></i> Close</button>

				</div>
    </div>
  </div>
</div> 
 




			