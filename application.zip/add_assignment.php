<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('teacher_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
					
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">ASSIGNMENTS</h1>
   		 		</div>
					
	<div class="row">
	
                <div class="col-xl col-lg-7">
	<div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<h6 class="alert alert-info m-0 font-weight-bold text-primary">Add assignment</h6>
				</div>
				
					<center>
										<form class="v" id="add_downloadble" method="post" enctype="multipart/form-data" name="upload" >
											<div class="form-group position-relative">
													<label class="control-label" for="inputEmail">File</label>
													<div class="form-group position-relative">
														<input name="uploaded_file"  class="input-file uniform_on" id="fileInput" type="file" >
														<input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
														<input type="hidden" name="id" value="<?php echo $session_id ?>"/>
													</div>
												</div>
												<div class="form-group position-relative">
													<div class="form-group position-relative">
														<input type="text" name="name" Placeholder="Assigment Name"  class="input">
													</div>
												</div>
												<div class="form-group position-relative">
													<div class="form-group position-relative">
													<textarea id="assigntextare"  rows="5" placeholder="Description" name="desc" required></textarea>
													</div>
												</div>


												
												</center>	
                
												<script src="admin/swal.js"></script>
											<script>
			jQuery(document).ready(function($){
				$("#add_downloadble").submit(function(e){
					e.preventDefault();
					var _this = $(e.target);
					var formData = new FormData($(this)[0]);
					$.ajax({
						type: "POST",
						url: "add_assignment_save.php",
						data: formData,
						success: function(html){
							swal({title:"Uploaded" ,text:"Assignment Successfully Added", icon:"success"});
						setTimeout(() => {location.reload();
							
						}, 1500);
						},
						cache: false,
						contentType: false,
						processData: false
					});
				});
			});
			</script>	
	
		
<div class="card shadow mb-4  v">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
               
				
				<h6 class="alert alert-info m-0 font-weight-bold text-primary">Check The Class you want to put this file.</h6>
				<div class="float-left">
								Check All <input type="checkbox"  name="selectAll" id="checkAll" />
								<script>
								$("#checkAll").click(function () {
									$('input:checkbox').not(this).prop('checked', this.checked);
								});
								</script>					
							</div>
							</div>
							<div class="card-body b">

							<div class="table-resposive">
											<table cellpadding="0" cellspacing="0" border="0" class="table" id="">

										<thead>
										        <tr>
												<th></th>
												<th>Class Name</th>
												<th>Subject </th>
												</tr>
												
										</thead>
										<tbody>
											
                              	<?php $query = mysqli_query($conn,"select * from teacher_class
										LEFT JOIN class ON class.class_id = teacher_class.class_id
										LEFT JOIN subject ON subject.subject_id = teacher_class.subject_id
										where teacher_id = '$session_id' and school_year = '$school_year' ")or die(mysqli_error());
										$count = mysqli_num_rows($query);
										
									
										while($row = mysqli_fetch_array($query)){
										$id = $row['teacher_class_id'];
				
										?>                             
										<tr id="del<?php echo $id; ?>">
											<td width="30">
												<input id="" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
											</td>
											<td><?php echo $row['class_name']; ?></td>
											<td><?php echo $row['subject_code']; ?></td>                                                                   
										</tr>
                         
						<?php } ?>
							
						   
                              
										</tbody>
									</table>
						
									
                                </div>
	</div>
									<center>
									<div class="form-group position-relative">
												<div class="form-group position-relative">
													<button name="Upload" type="submit" value="Upload" class="btn btn-success" /><i class="fas fa-upload"></i>&nbsp;Upload</button>
												</div>
									</div>
									</center>
							</form>		
								</div>
                            </div>
                        </div>
                    </div>                    </div>

			<?php include('admin/footer.php'); ?>
<?php include('script.php'); ?>


