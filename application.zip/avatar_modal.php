<div class="fade modal" id="sampleModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Change Avatar</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <form method="post" action="teacher_avatar.php" enctype="multipart/form-data">
							<center>	
								<div class="control-group">
								<div class="controls">
									<input name="image" class="input-file uniform_on" id="fileInput" type="file" required>
								</div>
								</div>
							</center>			
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i> Close</button>
		<button class="btn btn-info" name="change"><i class="fas fa-save icon-large"></i> Save</button>
		</div>
    </div>
  </div>
</div> 
 
<div class="fade modal" id="profile">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Your Profile</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <form method="post" action="teacher_avatar.php" enctype="multipart/form-data">
	  <div class="alert alert-info"><i class="fas fa-user"></i> About Me</div>
								<?php $query= mysqli_query($conn,"select * from teacher where teacher_id = '$session_id'")or die(mysqli_error());
								$row = mysqli_fetch_array($query);
								$dept=$row['department_id'];
								 $queryd= mysqli_query($conn,"select * from department where department_id = '$dept'")or die(mysqli_error());
								$rowa = mysqli_fetch_array($queryd);
						?>
  									<strong><center>
									  
									  <div class="form-group position-relative">
									  <div class="controls">
									    <a class=""><img class="img-profile rounded-circle" width="80" height="90"   src="admin/<?php echo $row['location']; ?>"></a>
									 </div>
									 <br />
									 <div class="controls">
									  <label for="d">Department:</label>
									  <?php echo $rowa['department_name']; ?>
									  								  </div>
									  <div class="controls">
									  <label for="fn">First Name:</label>
									  <input type="txt" value="<?php echo $row['firstname']; ?>" name="fn">
									  </div>
									  <div class="controls">
									  <label for="lm">Last Name:</label>
									  <input type="txt" value="<?php echo $row['lastname']; ?>" name="lm">
									  </div>
									  <div class="controls">
									  <label for="un">User Name:</label>
									  <input type="txt" value="<?php echo $row['username']; ?>" name="un">
									  </div>
									  <div class="controls">
									  <label for="ab">About  :</label>
									  <textarea name="ab" id="" cols="20"><?php echo $row['about']; ?></textarea>
									 </div>
									  </div>
									  </strong></center>
                               			
      </div>
      <div class="modal-footer">
	  <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i> Close</button>
		
		</div>
    </div>
  </div>
</div> 
 






