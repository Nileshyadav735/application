<div id="user_delete" class="fade modal" aria-labelledby="myModalLabel" aria-hidden="true" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Copy File?</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	 						<center>
										<div class="control-group">
										
                                   		<div class="control-group">
                                          <div class="controls">
										  <p>Share</p>
										<div class="control-group">
											<label>To:</label>
                                          <div class="controls">
                                            <select name="teacher_id1"  class="" required>
                                             	<option></option>
											<?php
											$query = mysqli_query($conn,"select * from teacher order by firstname");
											while($row = mysqli_fetch_array($query)){
											
											?>
											
											<option value="<?php echo $row['teacher_id']; ?>"><?php echo $row['firstname']; ?> <?php echo $row['lastname']; ?> </option>
											
											<?php } ?>
                                            </select>
							
                                          </div>
                                        </div>
										
										  	<button name="share" class="btn btn-success"><i class="icon-copy"></i> Share</button>
                                          </div>
                                        </div>
                                        </div>
										
									
										</center>
										
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
				</div>
    </div>
  </div>
</div> 
 