<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('student_sidebar.php'); ?>
<?php include('navbar_student.php'); ?>
<body>
<style>
									.v,button{
								margin-left:10px;
								margin-top:10px;
								margin-bottom:10px;
								margin-right:10px;
}</style>
        <div class="container-fluid">
		<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">BACKPACK</h1>
   		 		</div>
	<div class="row">
	<div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Your Backpack</h6>
					
				<div class="float-right">
															Check All <input type="checkbox"  name="selectAll" id="checkAll" />
								<script>
								$("#checkAll").click(function () {
									$('input:checkbox').not(this).prop('checked', this.checked);
								});
								</script>	
											
							</div>
							</div>		
					

<form action="delete_backpack.php" method="post">
<a data-toggle="modal" href="#backup_delete" id="delete"  class="btn btn-danger v b" name=""><i class="fas fa-trash icon-large"></i></a>									<br>
<?php include('modal_backpack_delete.php'); ?>

								<?php
								$query_backpack = mysqli_query($conn,"select * FROM student_backpack where student_id = '$session_id'  order by fdatein DESC ")or die(mysqli_error());
								$num_row = mysqli_num_rows($query_backpack);
								if ($num_row > 0){

?>


<input type="text" id="myInput" class="fas fa-search" onkeyup="myFunction()" placeholder=" &#xF002; Search for File.." title="Type in a name">

<div class="card-body b">

                        <div class="table-responsive">
						
									
									  <table cellpadding="0" cellspacing="0"  width="100%"  class="table" id="example" >

									  <thead>
										        <tr>
												<th></th>
												<th>Date Upload</th>
												<th>File Name</th>
												<th>Description</th>
												<th></th>
												</tr>
										</thead>
										<tbody>
                              		<?php
										$query = mysqli_query($conn,"select * FROM student_backpack where student_id = '$session_id'  order by fdatein DESC ")or die(mysqli_error());
										while($row = mysqli_fetch_array($query)){
										$id  = $row['file_id'];
									?>                              
										<tr id="del<?php echo $id; ?>">
										<td width="30">
											<input id="" class="" name="selector[]" type="checkbox" value="<?php echo $id; ?>">
										</td>
										 <td><?php echo $row['fdatein']; ?></td>
                                         <td><?php  echo $row['fname']; ?></td>
                                         <td><?php echo $row['fdesc']; ?></td>                                      
                                         <td width="30"><a href="<?php echo $row['floc']; ?>"><i class="fas fa-download icon-large"></i></a></td>                                      
										</tr>
									<?php } ?>
										</tbody>
									</table>
									</form>
									<?php }else{ ?>
									<div class="alert alert-info v"><i class="fas fa-sign"></i> No Files Inside Your Backpack.</div>
									<?php } ?>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('admin/footer.php'); ?>
        </div>

		<?php include('script.php'); ?>
    </body>
</html>