<div class="fade modal" id="sampleModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
	  <h3 id="myModalLabel">Change Avatar</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <form method="post" action="student_avatar.php" enctype="multipart/form-data">
							<center>	
								<div class="control-group">
								<div class="controls">
									<input name="image" class="input-file uniform_on" id="fileInput" type="file" required>
								</div>
								</div>
							</center>			
					
      </div>
      <div class="modal-footer">
	  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i> Close</button>
		<button class="btn btn-info" name="change"><i class="fas fa-save icon-large"></i> Save</button>
		</div>
    </div>
  </div>
</div> 
 



