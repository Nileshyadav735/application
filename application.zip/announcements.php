<?php $get_id = $_GET['id']; ?>
<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
<?php include('class_sidebar.php'); ?>
<?php include('navbar_teacher.php'); ?>
<div class="container-fluid">
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    					<h1 class="h3 mb-0 text-gray-800">Announcement</h1>
</div>
<div class="row">
<div class="col-xl-4 col-lg-7">
				<div class="card shadow mb-4">
		<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Add Announcements</h6>
				<div class="float-right">
							
								</div>
                            </div>
							<div class="card-body b v">

							<form method="post">
								<textarea name="content" placeholder="start typing here..." id=""></textarea>
							
								

</div>
<center>
								<button name="post"  class="btn btn-info"><i class="fas fa-check icon-large"></i> Post</button>
								</center>
								</form>
							</div>
							</div>

<div class="col-xl-8 col-lg-7">
				<div class="card shadow mb-4">
		<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Subject Announcements</h6>
				<div class="float-right">
							
								</div>
                            </div>
<?php
	if (isset($_POST['post'])){
$content = $_POST['content'];
mysqli_query($conn,"insert into teacher_class_announcements (teacher_class_id,teacher_id,content,date) values('$get_id','$session_id','$content',NOW())")or die(mysqli_error());
mysqli_query($conn,"insert into notification (teacher_class_id,notification,date_of_notification,link) value('$get_id','Add Annoucements',NOW(),'announcements_student.php')")or die(mysqli_error());
?>
<script>
window.location = 'announcements.php<?php echo '?id='.$get_id; ?>';
</script>
<?php
}
?>
	<div class="card-body b v">
	<ul style="list-style-type: decimal;">						
<?php
								 $query_announcement = mysqli_query($conn,"select * from teacher_class_announcements
																	where teacher_id = '$session_id'  and  teacher_class_id = '$get_id' order by date DESC
																	")or die(mysqli_error());
								 while($row = mysqli_fetch_array($query_announcement)){
								 $id = $row['teacher_class_announcements_id'];
?>											
<div class="post"  id="del<?php echo $id; ?>">
<strong><li><?php echo $row['content']; ?></li> </strong>
<div class="float-right v"><i class="fas fa-calendar"></i> <?php echo $row['date']; ?></strong> <a class="btn btn-link"  href="#delete<?php echo $id; ?>" data-toggle="modal" ><i class="fas fa-times"></i> <?php include("remove_sent_message_modal.php"); ?> </a>										</div>

<form  method="post"  action="edit_post.php<?php echo '?id='.$get_id; ?>">
												<input type="hidden" name="id" value="<?php echo $id; ?>">
												<button class="btn btn-info v" name="edit"><i class="fas fa-pen"></i>edit </button> 
												</form>
										
										
								<hr>

								<?php } ?>
								</ul>
 </div>
                           
 </div>
 </div>	<script src="admin/swal.js"></script>


					<script type="text/javascript">
	$(document).ready( function() {

		
		$('.remove').click( function() {
		var id = $(this).attr("id");
			$.ajax({
			type: "POST",
			url: "remove_announcements.php",
			data: ({id: id}),
			cache: false,
			success: function(html){
			$("#del"+id).fadeOut('fast', function(){ $(this).remove();}); 
			$('#delete'+id).modal('hide');
			swal("Your Post is Successfully Deleted");
			setTimeout(() => { location.reload();}, 700);
			}
			}); 
			
			return false;
		});				
	});

</script>
			</div>
			</div>	
                                </div>
			</div>

<?php include('admin/footer.php'); ?>

		<?php include('script.php'); ?>
	