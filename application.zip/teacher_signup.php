<?php
include('admin/dbcon.php');
$username = $_POST['username'];
$password = $_POST['password'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$department_id = $_POST['department_id'];

$register=mysqli_query($conn,"INSERT INTO `teacher` (`teacher_id`, `username`, `password`, `firstname`, `lastname`, `department_id`, `location`, `about`, `teacher_status`, `status`) VALUES (NULL, '$username', '$password', '$firstname', '$lastname', '$department_id', '', '', 'Registered', '0')")or die(mysqli_error());

if($register){
echo 'true';
}else{
echo 'false';
}
?>