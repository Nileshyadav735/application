<style>
.form-popup {
  display: none;
  bottom: 0;
  right: 15px;
   z-index: 9;
}
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
</div>
<div class="form-popup" id="myForm">

<div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Add Quiz</h6>
				</div>
<form class="form-horizontal form-container v" method="post">
										<div class="form-group position-relative">
											<label class="control-label" for="inputEmail">Quiz Title</label>
											<div class="controls">
											<input type="text" name="quiz_title" id="inputEmail" placeholder="Quiz Title">
											</div>
										</div>
										<div class="form-group position-relative">
											<label class="control-label" for="inputPassword">Quiz Description</label>
											<div class="controls">
											<input type="text" class="span8" name="description" id="inputPassword" placeholder="Quiz Description" required>
											</div>
										</div>										
										<div class="form-group position-relative v">
										<div class="controls">										
										<button name="save1" type="submit" class="btn btn-success v "><i class="fas fa-save"></i> Save</button>
										<button type="button" class="btn btn-danger" onclick="closeForm()"><i class="fas fa-times"></i>Close</button>
										</div>
										</div>
										</form>		
										</div>


										</div>					
										<?php
										if (isset($_POST['save1'])){
										$quiz_title = $_POST['quiz_title'];
										$description = $_POST['description'];
										mysqli_query($conn,"insert into quiz (quiz_title,quiz_description,date_added,teacher_id) values('$quiz_title','$description',NOW(),'$session_id')")or die(mysqli_error());
										?>

										<script>
										
										window.location = 'teacher_quiz.php';
										</script>
										<?php
										}
										?>