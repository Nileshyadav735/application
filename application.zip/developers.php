<div class="fade modal" role="dialog" aria-labelledby="myModalLabel" id="developers">
  <div class="modal-dialog modal-xl">
    <div class="modal-content cascading-modal">
      <div class="modal-header">
	  <h3 id="myModalLabel">Developers</h3>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	
	  <style>
	  .main1 {
        background-color: #FFFFFF;
        width: 400px;
        height: 400px;
		margin: auto;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
       }
</style>

	  <div class="row">
                        <!-- block -->
                        <div class="col-md-4 ml-auto main1">
							<center>
								<img id="developers" src="https://cdn.glitch.com/49d34dc6-8fbd-46bb-8221-b99ffd36f1af%2Fapple-touch-icon.png?v=1566861131254" width="80" height="90" class="rounded-circle">
								<hr>
																				<p>Name:  Nilesh yadav</p>

										<p>Address:Kharghar</p>
										<p>Email: NY@gmail.com</p>
										<p>Position: Programmer</p>
								</center>
								</div>								

								<div class="col-md-4 ml-auto main1">
                               
															<center>
							<img id="developers" src="https://cdn.glitch.com/49d34dc6-8fbd-46bb-8221-b99ffd36f1af%2Fapple-touch-icon.png?v=1566861131254" width="80" height="90" class="rounded-circle">
								<hr>
												<p>Name: Atul Kadam</p>
										<p>Address: Kharghar</p>
										<p>Email: ATK@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								
								</div>

								<div class="col-md-4 ml-auto main1">
                               
															<center>
								<img id="developers" src="https://cdn.glitch.com/49d34dc6-8fbd-46bb-8221-b99ffd36f1af%2Fapple-touch-icon.png?v=1566861131254" width="80" height="90" class="rounded-circle">
								<hr>
												<p>Name: Rajat nevse</p>
										<p>Address: Kharghar</p>
										<p>Email: RJN@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
								

									
</div>
      <div class="modal-footer">
	  <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true"><i class="fas fa-times icon-large"></i>close</button>
	</div>
    </div>
  </div>
</div> 
 



